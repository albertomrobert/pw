MULTI-LANGUAGE DEFAULT PROFILE

Please see this HTML document for an introduction to how this 
site profile works: 

http://processwire.com/docs/tutorials/default-site-profile/

The files in this templates directory are largely identical to those 
in the non-multi-language version except for use of these static text
translation functions in _main.php and search.php: 

  __('text');
  _x('text', 'context label'); 
  _n('singular', 'plural', $count); 

Please see this page for more information about how these are used:
http://processwire.com/api/multi-language-support/code-i18n/

