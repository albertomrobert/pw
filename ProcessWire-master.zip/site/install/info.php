<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "recetas", 
	'summary' => "", 
	'screenshot' => ""
	);
