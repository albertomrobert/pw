# --- WireDatabaseBackup {"time":"2016-04-05 20:27:17","user":"","dbName":"recetas","description":"","tables":[],"excludeTables":["pages_drafts","pages_roles","permissions","roles","roles_permissions","users","users_roles","user","role","permission"],"excludeCreateTables":[],"excludeExportTables":["field_roles","field_permissions","field_email","field_pass","caches","session_login_throttle","page_path_history"]}

DROP TABLE IF EXISTS `caches`;
CREATE TABLE `caches` (
  `name` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expires` (`expires`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_admin_theme`;
CREATE TABLE `field_admin_theme` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_admin_theme` (`pages_id`, `data`) VALUES('41', '165');

DROP TABLE IF EXISTS `field_body`;
CREATE TABLE `field_body` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_body` (`pages_id`, `data`) VALUES('27', '<h3>The page you were looking for is not found.</h3><p>Please use our search engine or navigation above to find the page.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1', '<h2>What is ProcessWire?</h2>\r\n\r\n<p>ProcessWire gives you full control over your fields, templates and markup. It provides a powerful template system that works the way you do. Not to mention, ProcessWire\'s API makes working with your content easy and enjoyable. <a href=\"http://processwire.com\">Learn more</a></p>\r\n\r\n<h3>About this site profile</h3>\r\n\r\n<p>This is a basic minimal site for you to use in developing your own site or to learn from. There are a few pages here to serve as examples, but this site profile does not make any attempt to demonstrate all that ProcessWire can do. To learn more or ask questions, visit the <a href=\"http://www.processwire.com/talk/\" target=\"_blank\">ProcessWire forums</a> or <a href=\"http://modules.processwire.com/categories/site-profile/\">browse more site profiles</a>. If you are building a new site, this minimal profile is a good place to start. You may use these existing templates and design as they are, or you may replace them entirely.</p>\r\n\r\n<h3>Browse the site</h3>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1002', '<h2>Ut capio feugiat saepius torqueo olim</h2>\r\n\r\n<h3>In utinam facilisi eum vicis feugait nimis</h3>\r\n\r\n<p>Iusto incassum appellatio cui macto genitus vel. Lobortis aliquam luctus, roto enim, imputo wisi tamen. Ratis odio, genitus acsi, neo illum consequat consectetuer ut.</p>\r\n\r\n<blockquote>\r\n<p>Wisi fere virtus cogo, ex ut vel nullus similis vel iusto. Tation incassum adsum in, quibus capto premo diam suscipere facilisi. Uxor laoreet mos capio premo feugait ille et. Pecus abigo immitto epulae duis vel. Neque causa, indoles verto, decet ingenium dignissim.</p>\r\n</blockquote>\r\n\r\n<p>Patria iriure vel vel autem proprius indoles ille sit. Tation blandit refoveo, accumsan ut ulciscor lucidus inhibeo capto aptent opes, foras.</p>\r\n\r\n<h3>Dolore ea valde refero feugait utinam luctus</h3>\r\n\r\n<p><img alt=\"Copyright by Austin Cramer for DesignIntelligence. This is a placeholder while he makes new ones for us.\" class=\"align_left\"	src=\"/site/assets/files/1002/psych_cartoon_4-20.400x0.jpg\" />Usitas, nostrud transverbero, in, amet, nostrud ad. Ex feugiat opto diam os aliquam regula lobortis dolore ut ut quadrum. Esse eu quis nunc jugis iriure volutpat wisi, fere blandit inhibeo melior, hendrerit, saluto velit. Eu bene ideo dignissim delenit accumsan nunc. Usitas ille autem camur consequat typicus feugait elit ex accumsan nutus accumsan nimis pagus, occuro. Immitto populus, qui feugiat opto pneum letalis paratus. Mara conventio torqueo nibh caecus abigo sit eum brevitas. Populus, duis ex quae exerci hendrerit, si antehabeo nobis, consequat ea praemitto zelus.</p>\r\n\r\n<p>Immitto os ratis euismod conventio erat jus caecus sudo. code test Appellatio consequat, et ibidem ludus nulla dolor augue abdo tego euismod plaga lenis. Sit at nimis venio venio tego os et pecus enim pneum magna nobis ad pneum. Saepius turpis probo refero molior nonummy aliquam neque appellatio jus luctus acsi. Ulciscor refero pagus imputo eu refoveo valetudo duis dolore usitas. Consequat suscipere quod torqueo ratis ullamcorper, dolore lenis, letalis quia quadrum plaga minim.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1001', '<h2>Si lobortis singularis genitus ibidem saluto.</h2><p>Dolore ad nunc, mos accumsan paratus duis suscipit luptatum facilisis macto uxor iaceo quadrum. Demoveo, appellatio elit neque ad commodo ea. Wisi, iaceo, tincidunt at commoveo rusticus et, ludus. Feugait at blandit bene blandit suscipere abdo duis ideo bis commoveo pagus ex, velit. Consequat commodo roto accumsan, duis transverbero.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1004', '<h2>Pertineo vel dignissim, natu letalis fere odio</h2><p>Magna in gemino, gilvus iusto capto jugis abdo mos aptent acsi qui. Utrum inhibeo humo humo duis quae. Lucidus paulatim facilisi scisco quibus hendrerit conventio adsum.</p><h3>Si lobortis singularis genitus ibidem saluto</h3><ul><li>Feugiat eligo foras ex elit sed indoles hos elit ex antehabeo defui et nostrud.</li><li>Letatio valetudo multo consequat inhibeo ille dignissim pagus et in quadrum eum eu.</li><li>Aliquam si consequat, ut nulla amet et turpis exerci, adsum luctus ne decet, delenit.</li><li>Commoveo nunc diam valetudo cui, aptent commoveo at obruo uxor nulla aliquip augue.</li></ul><p>Iriure, ex velit, praesent vulpes delenit capio vero gilvus inhibeo letatio aliquip metuo qui eros. Transverbero demoveo euismod letatio torqueo melior. Ut odio in suscipit paulatim amet huic letalis suscipere eros causa, letalis magna.</p><ol><li>Feugiat eligo foras ex elit sed indoles hos elit ex antehabeo defui et nostrud.</li><li>Letatio valetudo multo consequat inhibeo ille dignissim pagus et in quadrum eum eu.</li><li>Aliquam si consequat, ut nulla amet et turpis exerci, adsum luctus ne decet, delenit.</li><li>Commoveo nunc diam valetudo cui, aptent commoveo at obruo uxor nulla aliquip augue.</li></ol>');

DROP TABLE IF EXISTS `field_category`;
CREATE TABLE `field_category` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1024', 'Aperitivo');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1025', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1026', 'Bebida');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1027', 'Bebida');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1028', 'Bebida');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1029', 'Bebida');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1030', 'Bebida');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1031', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1032', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1033', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1034', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1035', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1036', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1037', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1038', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1039', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1040', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1041', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1042', 'Aperitivo');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1043', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1044', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1045', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1046', 'Aperitivo');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1047', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1048', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1049', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1050', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1051', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1052', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1053', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1055', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1056', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1057', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1058', 'Bebida');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1059', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1060', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1061', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1062', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1063', 'Plato');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1064', 'Aperitivo');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1065', 'Postre');
INSERT INTO `field_category` (`pages_id`, `data`) VALUES('1066', 'Plato');

DROP TABLE IF EXISTS `field_crop`;
CREATE TABLE `field_crop` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_dificultad`;
CREATE TABLE `field_dificultad` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1025', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1032', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1024', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1026', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1027', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1028', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1029', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1030', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1031', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1033', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1034', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1035', '3');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1036', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1037', '3');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1038', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1039', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1040', '3');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1041', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1042', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1043', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1044', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1045', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1046', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1047', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1048', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1049', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1050', '3');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1051', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1052', '3');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1053', '3');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1055', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1056', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1057', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1058', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1059', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1060', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1061', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1062', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1063', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1064', '2');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1065', '1');
INSERT INTO `field_dificultad` (`pages_id`, `data`) VALUES('1066', '1');

DROP TABLE IF EXISTS `field_email`;
CREATE TABLE `field_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_headline`;
CREATE TABLE `field_headline` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_headline` (`pages_id`, `data`) VALUES('1', 'Minimal Site Profile');
INSERT INTO `field_headline` (`pages_id`, `data`) VALUES('1001', 'About Us');
INSERT INTO `field_headline` (`pages_id`, `data`) VALUES('27', '404 Page Not Found');

DROP TABLE IF EXISTS `field_images`;
CREATE TABLE `field_images` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1002', 'psych_cartoon_4-20.jpg', '0', 'Copyright by Austin Cramer for DesignIntelligence. This is a placeholder while he makes new ones for us.', '2014-07-25 15:30:53', '2014-07-25 15:30:39');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1', 'rough_cartoon_puppet.jpg', '1', 'Copyright by Austin Cramer for DesignIntelligence. This is a placeholder while he makes new ones for us.', '2014-07-25 15:30:14', '2014-07-25 15:29:22');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1', 'airport_cartoon_3.jpg', '0', 'Copyright by Austin Cramer for DesignIntelligence. This is a placeholder while he makes new ones for us.', '2014-07-25 15:30:14', '2014-07-25 15:29:22');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1027', 'gin_tonic.jpg', '0', '[null]', '2016-03-21 20:00:30', '2016-03-21 20:00:30');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1028', 'smoothie_de_banana.jpg', '0', '[null]', '2016-03-21 20:32:17', '2016-03-21 20:32:17');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1033', 'maxresdefault.jpg', '0', '[null]', '2016-03-22 02:44:54', '2016-03-22 02:44:54');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1043', '1354585499_1-1.jpg', '0', '[null]', '2016-03-22 03:08:15', '2016-03-22 03:08:15');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1035', 'img03882-20101225-2300.jpg', '0', '[null]', '2016-03-22 02:50:42', '2016-03-22 02:50:42');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1036', 'cordero-patatas.jpg', '0', '[null]', '2016-03-22 02:52:49', '2016-03-22 02:52:49');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1031', 'recetachocolatealataza.jpg', '0', '[null]', '2016-03-21 20:44:37', '2016-03-21 20:44:37');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1039', 'sufle.jpg', '0', '[null]', '2016-03-22 03:01:17', '2016-03-22 03:01:17');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1040', 'img-blog04-wordplay-1500x993.jpg', '0', '[null]', '2016-03-22 03:05:16', '2016-03-22 03:05:16');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1038', 'tortilla-de-patatas-detalle.jpg', '0', '[null]', '2016-03-22 03:00:10', '2016-03-22 03:00:10');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1034', 'martin-berasategui-solomillo-asado-con-tocineta-rf.jpg', '0', '[null]', '2016-03-22 02:48:30', '2016-03-22 02:48:30');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1042', 'ensalada-de-perdiz-escabechada.jpg', '0', '[null]', '2016-03-22 03:07:29', '2016-03-22 03:07:29');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1046', 'caprese-pasta-salad-1.jpg', '0', '[null]', '2016-03-22 03:13:03', '2016-03-22 03:13:03');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1044', 'pis1xxx.jpg', '0', '[null]', '2016-03-22 03:16:00', '2016-03-22 03:16:00');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1047', 'tallarines.jpg', '0', '[null]', '2016-03-22 03:17:10', '2016-03-22 03:17:10');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1057', 'helado-de-almendras-hogarmania-848x477x80xx.jpg', '0', '[null]', '2016-03-22 03:38:47', '2016-03-22 03:38:47');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1049', '321451fr.jpg', '0', '[null]', '2016-03-22 03:19:45', '2016-03-22 03:19:45');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1052', '17865_l.jpg', '0', '[null]', '2016-03-22 03:25:56', '2016-03-22 03:25:56');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1051', 'baklava.jpg', '0', '[null]', '2016-03-22 03:24:57', '2016-03-22 03:24:57');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1056', 'california-roll-1.jpg', '0', '[null]', '2016-03-22 03:28:20', '2016-03-22 03:28:20');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1026', 'refresco_de_granada-2.jpg', '0', '[null]', '2016-03-21 19:58:35', '2016-03-21 19:58:35');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1030', 'lemon-tea-563806_19201.jpg', '0', '[null]', '2016-03-21 20:42:35', '2016-03-21 20:42:35');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1025', 'risotto-con-setas.jpg', '0', '[null]', '2016-03-21 19:56:48', '2016-03-21 19:56:48');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1029', 'granizado-de-cafe2.jpg', '0', '[null]', '2016-03-21 20:40:43', '2016-03-21 20:40:43');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1032', 'pollo-villeroy.jpg', '0', '[null]', '2016-03-22 02:40:57', '2016-03-22 02:40:57');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1061', '1431d14.jpg', '0', '[null]', '2016-03-29 20:20:35', '2016-03-29 20:20:35');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1053', 'calzone-de-queso-huevo-y-jamon.jpg', '0', '[null]', '2016-03-22 03:26:42', '2016-03-22 03:26:42');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1048', 'pastel-bavarios.jpg', '0', '[null]', '2016-03-22 03:18:02', '2016-03-22 03:18:02');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1050', 'spa50348.jpg', '0', '[null]', '2016-03-22 03:23:23', '2016-03-22 03:23:23');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1055', 'chocolate-brownies_10950-1.jpg', '0', '[null]', '2016-03-22 03:27:41', '2016-03-22 03:27:41');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1058', 'blue-monday.jpg', '0', '[null]', '2016-03-22 03:49:02', '2016-03-22 03:49:02');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1024', '11280662_10205746368851513_282210350_o.jpg', '0', '[null]', '2016-03-21 17:23:22', '2016-03-21 17:23:22');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1041', 'cuscus-de-cordero-al-estilo-mozarabe.jpg', '0', '[null]', '2016-03-22 03:06:37', '2016-03-22 03:06:37');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1045', 'sep_08_2013_035.jpg', '0', '[null]', '2016-03-22 03:11:49', '2016-03-22 03:11:49');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1059', 'ramen-japones-en-el-df.jpg', '0', '[null]', '2016-03-22 03:53:20', '2016-03-22 03:53:20');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1060', 'pizza.jpg', '0', '[null]', '2016-03-22 04:08:03', '2016-03-22 04:08:03');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1037', 'pechuga_limon.jpg', '0', '[null]', '2016-03-22 04:24:48', '2016-03-22 04:24:48');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1062', 'dorada-a-la-sal-con-patatas-al-limon-30-09-13.jpg', '0', '[null]', '2016-03-29 20:31:54', '2016-03-29 20:31:54');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1063', 'sushi_laks_nigri_1-1024x682.jpg', '0', '[null]', '2016-03-29 20:39:36', '2016-03-29 20:39:36');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1064', 'b0c16e3b00d4c2d746f8a570512c7a8f884c179c_r900_480_2.jpg', '0', '[null]', '2016-03-30 02:30:15', '2016-03-30 02:30:15');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1065', 'granizado-melon-thermomix.jpg', '0', '[null]', '2016-03-30 02:37:54', '2016-03-30 02:37:54');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1066', 'receta-de-omelette-de-espinacas.jpg', '0', '[null]', '2016-03-30 02:52:33', '2016-03-30 02:52:33');

DROP TABLE IF EXISTS `field_ingredientes`;
CREATE TABLE `field_ingredientes` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1024', '<ul><li>500 gr. de camarones sin cocer</li>\n	<li>200 gr. de surimi</li>\n	<li>1 cebolla grande</li>\n	<li>4 hojas de laurel</li>\n	<li>1 manojo de cilantro fresco</li>\n	<li>Pimienta negra recién molida</li>\n	<li>Aceite de oliva</li>\n	<li>Vinagre de manzana</li>\n	<li>Agua</li>\n	<li>Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1025', '<ul><li> 240 gr. de arroz Carnaroli o arborio</li>\n	<li> 2 chalotas</li>\n	<li> 6 setas calabaza, boletus o ceps pequeñas y una grande para decorar</li>\n	<li> 1 vaso de vino blanco</li>\n	<li> 70 gr. de mantequilla</li>\n	<li> 1 l. de caldo de ave</li>\n	<li> 100 ml. de crema de leche para cocinar</li>\n	<li> 100 gr. de queso manchego</li>\n	<li> Aceite de oliva virgen</li>\n	<li> Sal</li>\n	<li> Pimienta negra molida</li>\n	<li> Perejil picado</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1026', '<ul><li>Hielo para llenar una jarra de 1-1 y 1/2 l.</li>\n	<li> 1 granada</li>\n	<li> Hojas de menta abundantes</li>\n	<li> Zumo de 1 limón</li>\n	<li> Agua mineral o agua con gas</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1027', '<ul><li> Ginebra</li>\n	<li> Tónica</li>\n	<li> Peladura de lima o limón</li>\n	<li> Hielo en cubitos</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1028', '<ul><li>2 plátanos</li>\n	<li> 1 taza de leche</li>\n	<li> 62 gr. de azúcar</li>\n	<li> 1 taza de hielo</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1029', '<ul><li>400 ml. de café helado</li>\n	<li> 3 cucharadas de sirope de azúcar</li>\n	<li> Hielo en cubitos</li>\n	<li> Nata</li>\n	<li> Cacao en polvo</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1030', '<ul><li> 5 saquitos de té</li>\n	<li> 3 cucharadas de azúcar</li>\n	<li> 1 vaso de zumo de limón</li>\n	<li> 1 l. de agua</li>\n	<li> Hielo</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1031', '<ul><li> 250 ml. de leche</li>\n	<li> 75 gr. de chocolate negro para postres</li>\n	<li> 20 gr. de azúcar</li>\n	<li> 1 cucharada sopera de maizena</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1056', '<p>Para el arroz</p>\n\n<ul><li>300 g de arroz para sushi</li>\n	<li>350 ml de agua</li>\n	<li>2 cucharadas de vinagre de arroz</li>\n	<li>1/4 de cucharadita de sal</li>\n	<li>1 cucharadita de azúcar</li>\n</ul><p>Para el relleno</p>\n\n<ul><li>Algas nori (láminas)</li>\n	<li>1 aguacate</li>\n	<li>10 palitos de cangrejo (surimi)</li>\n	<li>1 Pepino</li>\n	<li>Semillas de sésamo</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1032', '<p><strong>Para la pechuga:</strong></p>\n\n<ul><li> 2 pechugas de pollo</li>\n	<li> Harina</li>\n	<li> 2 huevos</li>\n	<li> Aceite de oliva para freír</li>\n	<li> Pimienta</li>\n	<li> Sal</li>\n</ul><p><strong>Para la salsa:</strong></p>\n\n<ul><li> 1,5 cucharada de mantequilla</li>\n	<li> 1,5 cucharada de harina</li>\n	<li> 250 ml. de caldo de pollo</li>\n	<li> 100 ml. de vino blanco</li>\n	<li> 2 limones</li>\n	<li> Perejil blanco</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1033', '<ul><li>1 de solomillo de pavo</li>\n	<li> 3 cucharadas de salsa de soja</li>\n	<li> 1 cucharada de miel</li>\n	<li> 2 cucharadas de mostaza antigua</li>\n	<li> 1 cebolla</li>\n	<li> 1 pimiento rojo</li>\n	<li> 1 pimiento verde</li>\n	<li> Aceite de oliva</li>\n	<li> Vino blanco dulce</li>\n	<li> Agua</li>\n	<li> Pimienta negra</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1034', '<ul><li> 2 solomillos de cerdo</li>\n	<li> Aceite de oliva</li>\n	<li> Sal</li>\n	<li> Pimienta molida</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1035', '<ul><li>1 pieza de solomillo de 1 kg.</li>\n	<li> 4 cebollitas francesas</li>\n	<li> 1 huevo</li>\n	<li> 1 bandeja de champiñones</li>\n	<li> 1 diente de ajo</li>\n	<li> 75 gr. de foie gras</li>\n	<li> 1 lámina de hojaldre</li>\n	<li> 3 cucharadas de mostaza de Dijon</li>\n	<li> Sal</li>\n	<li> Pimienta molida</li>\n	<li> Aceite de oliva</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1036', '<ul><li>1 pierna de cordero de 1 kg. aproximadamente</li>\n	<li> 3 patatas medianas</li>\n	<li> 125 ml. de vino blanco</li>\n	<li> 3 cucharadas de manteca de cerdo.</li>\n	<li> 1 cebolla</li>\n	<li> 5 dientes de ajo</li>\n	<li> 3 ramitas de perejil fresco</li>\n	<li> 2 ramitas de romero</li>\n	<li> 2 hoja de laurel</li>\n	<li> Aceite de oliva</li>\n	<li> Agua</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1037', '<ul><li> 2 pechugas de pavo limpias y abiertas en forma de libro</li>\n	<li> 3 manzanas golden medianas</li>\n	<li> 1 puñadito de pasas sultanas</li>\n	<li> 1 puñadito de nueces peladas</li>\n	<li> 150 ml. de caldo de pollo</li>\n	<li> 150 ml. de sidra</li>\n	<li> 2 ramitas de tomillo fresco</li>\n	<li> 2 ramitas de romero fresco</li>\n	<li> 1 cucharadita de maicena (opcional)</li>\n	<li> Molinillo de pimienta</li>\n	<li> Canela en polvo</li>\n	<li> Aceite de oliva</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1038', '<ul><li>500 gr. de patatas</li>\n	<li> 4 huevos</li>\n	<li> 2 cebolletas</li>\n	<li> Aceite de oliva virgen extra</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1039', '<ul><li> 50 ml. de nata</li>\n	<li> 4 huevos</li>\n	<li> 120 gr. de mozzarella</li>\n	<li> 100 gr. de virutas de beicon</li>\n	<li> 1 cucharadita de perejil picado</li>\n	<li> 1 cucharadita de crema de rábano picante</li>\n	<li> 2 cucharadas de mostaza de Dijon</li>\n	<li> 1 cucharadita de cebollino picado</li>\n	<li> Pimienta</li>\n	<li> Sal</li>\n	<li> 30 gr. de mantequilla atemperada</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1057', '<ul><li>100 g de almendras fileteadas</li>\n	<li>1/4 litro de nata para montar </li>\n	<li>2 claras de huevo</li>\n	<li>80 gr. de azúcar </li>\n	<li>60 ml de licor de almendras</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1040', '<ul><li>450 gr. de carne de ternera picada</li>\n	<li> 1 cebolleta</li>\n	<li> 5 huevos (4 de ellos cocidos)</li>\n	<li> Pan rallado</li>\n	<li> Perejil fresco</li>\n	<li> Pimienta negra molida</li>\n	<li> Sal</li>\n	<li> Nuez moscada</li>\n	<li> Aceite de oliva</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1041', '<ul><li>250 gr. de carne de cordero</li>\n	<li> 250 gr. de cuscús</li>\n	<li> 1 cebolla</li>\n	<li> 20 pasas sultanas</li>\n	<li> 1 copita de vino dulce</li>\n	<li> 1 cucharada de harina</li>\n	<li> 1/2 cucharada de mantequilla</li>\n	<li> 1/2 cucharadita de jengibre molido</li>\n	<li> 1/2 pastilla de caldo de ave concentrado</li>\n	<li> Aceite de oliva</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1055', '<ul><li>150 gr. de chocolate negro para postres </li>\n	<li>200 gr. de mantequilla </li>\n	<li>200 gr. de azúcar </li>\n	<li>80 gr. de harina </li>\n	<li>4 huevos </li>\n	<li>10 nueces </li>\n	<li>agua </li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1042', '<ul><li>1 bote de perdiz en escabeche</li>\n	<li> 1 mix de lechuga</li>\n	<li> 1 cucharada de piñones</li>\n	<li> 1/2 docena de arándanos</li>\n	<li> 1/2 docena de frambuesas</li>\n	<li> Aceite de oliva</li>\n	<li> Vinagre de Módena</li>\n	<li> Sal</li>\n	<li> Pimienta molida</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1043', '<ul><li> 300 gr. de harina de trigo</li>\n	<li> 75 ml. de aceite de girasol</li>\n	<li> 1/2 cucharadita de sal</li>\n	<li> 125 ml. de agua</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1044', '<ul><li> 1/4 Kg. de calabacines</li>\n	<li> 1/4 Kg. de berenjenas</li>\n	<li> 1 cebolla grande</li>\n	<li> 1/4 Kg. de tomates rojos</li>\n	<li> 1 pimiento verde</li>\n	<li> 1 pimiento rojo</li>\n	<li> Sal</li>\n	<li> Aceite de oliva</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1045', '<ul><li>400 gr. de macarrones</li>\n	<li> 200 gr. de salsa de tomate frito</li>\n	<li> 100 gr. de aceitunas negras deshuesadas</li>\n	<li> 50 gr. de queso pecorino rallado</li>\n	<li> 3 dientes de ajo</li>\n	<li> Orégano</li>\n	<li> 1 guindilla roja</li>\n	<li> Aceite de oliva</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1046', '<ul><li> 200 gr. de espirales de pasta</li>\n	<li> 2 tomates grandes</li>\n	<li> 12 hojas de albahaca</li>\n	<li> 100 gr. de mozzarella</li>\n	<li> Aceite de oliva</li>\n	<li> Orégano</li>\n	<li> Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1047', '<ul><li>250 gr. de fideos chinos</li>\n	<li> 1 pimiento verde</li>\n	<li> 1 cebolla</li>\n	<li> 100 gr. de gambas peladas</li>\n	<li> Salsa de soja</li>\n	<li> Pimienta negra molida</li>\n	<li> Sal</li>\n	<li> Aceite de oliva</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1048', '<ul><li> 1/4 l. de nata líquida para montar mínimo 33%MG</li>\n	<li> 3 cucharadas de azúcar blanquilla</li>\n	<li> 3 hojas de gelatina neutra</li>\n	<li> 3 yogures</li>\n	<li> Leche fría</li>\n	<li> Aceite de girasol</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1049', '<p><strong>Para el helado:</strong></p>\n\n<ul><li> 1/2 l. de nata para montar</li>\n	<li> 150 ml. de leche condensada</li>\n	<li> 100 gr. de azúcar ó 80 gr. de miel</li>\n	<li> 1 cucharada de extracto de vainilla</li>\n</ul><p><strong>Para acompañar (opcional):</strong></p>\n\n<ul><li> Galletas oreo</li>\n	<li> M&amp;M\'s</li>\n	<li> Kit Kat</li>\n	<li> Huesitos</li>\n	<li> Galletas con pepitas de chocolate.</li>\n	<li> Sirope de chocolate</li>\n	<li> Sirope de caramelo</li>\n	<li> Nata montada</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1050', '<ul><li> 800 gr. de cerezas sin hueso</li>\n	<li> 300 ml. de vino tinto</li>\n	<li> 300 gr. de azúcar</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1051', '<ul><li>150 g de azúcar</li>\n	<li>300 g de pasta filo</li>\n	<li>100 g de pistachos</li>\n	<li>250 g de nueces</li>\n	<li>150 g de almendras</li>\n	<li>50 g de piñones</li>\n	<li>300 g de mantequilla</li>\n	<li>5 cucharadas de agua de azáhar</li>\n	<li>1 limón/ su jugo y su cáscara</li>\n	<li>1 rama de canela/ 2 cucharadas de canela molida</li>\n	<li>1 vaso de agua</li>\n	<li>2 clavos de olor</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1052', '<ul><li>1 berenjena grande</li>\n	<li>450 gr. de carne picada</li>\n	<li>1 cebolla mediana</li>\n	<li>2 dientes de ajo</li>\n	<li>4 tomates</li>\n	<li>120 gr. de queso parmesano rallado</li>\n	<li>Salsa bechamel (opcional)</li>\n	<li>Nuez moscada</li>\n	<li>Aceite de Oliva</li>\n	<li>Pimentón</li>\n	<li>Sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1053', '<p><strong>Para la masa del calzone:</strong></p>\n\n<ul><li> 200 gr. de harina de trigo</li>\n	<li> 12 gr. de levadura seca de panadero</li>\n	<li> 15 gr. de aceite de oliva</li>\n	<li> 135 ml. de agua</li>\n	<li> 1 puñadito de orégano</li>\n	<li> 1 cucharadita de sal</li>\n</ul><p><strong>Para el relleno:</strong></p>\n\n<ul><li> 75 gr. de queso provolone</li>\n	<li> 75 gr. de queso emmental</li>\n	<li> 90 gr. de jamón York</li>\n	<li> 65 gr. de pimientos del piquillo</li>\n	<li> 2 huevos</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1058', '<ul><li>Vodka</li>\n	<li>Blue Tropic</li>\n	<li>Sprite ó SevenUp</li>\n	<li>Rodaja de limón</li>\n	<li>Hielo</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1059', '<p>1 paquetes de fideos chuka<br />\n1 ajo fino cortado<br />\n1 cucharilla de jengibre fresco<br />\n1 cucharilla de aceite de oliva<br />\n2 tazas de caldo de pollo (ver receta más abajo)<br />\n1 taza de caldo dashi (ver receta más abajo)<br />\n1 cucharada de sake (licor de arroz)<br />\n1 cucharilla de sal<br />\n1 cucharilla de azúcar<br />\n3 cucharadas de salsa de soja<br />\n1 hoja de alga nori<br />\nPimienta<br />\nCebolleta china ( finamente picada )</p>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1060', '<ul><li>400 gr. de harina </li>\n	<li> 200 ml. de agua </li>\n	<li> 2 cucharadas de aceite de oliva virgen extra </li>\n	<li>una pizca de sal </li>\n	<li>un poco de harina (para espolvorear en la encimera)</li>\n	<li>Ingrientes al gusto (Queso, fiambre, aceitunas, setas, verduras, marisco...)</li>\n	<li>Albahaca u orégano</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1061', '<p>- Un par de filetes de atún fresco<br />\n- 70 ml de aceite de oliva virgen<br />\n- 35 ml de vinagre de Módena<br />\n- 3 cucharaditas de mostaza de Dijon<br />\n- Sal</p>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1062', '<ul><li>2 Doradas de unos 350 gramos cada una</li>\n	<li>2 kg de sal especial para el horno (sal muy gruesa)</li>\n	<li>Patatas o verduras al gusto para acompañar</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1063', '<ul><li>1 taza de arroz de sushi («sumeshi»)</li>\n	<li>30 gramos de atún fresco</li>\n	<li>30 gramos de salmón</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1064', '<ul><li>200 gr. de langostinos cocidos</li>\n	<li>200 gr. pescado al gusto</li>\n	<li>1 yema de huevo</li>\n	<li>50 gr. de harina</li>\n	<li>2 H<span style=\"line-height:1.6em;\">uevos</span></li>\n	<li>1 Cebolla</li>\n	<li>Aceite y perejil</li>\n	<li>Leche entera</li>\n	<li>Pan rallado</li>\n	<li>Caldo de pescado</li>\n	<li>Levadura y sal</li>\n</ul>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1065', '<p>1,5 kg. de melón</p>\n\n<p>1 vaso de zumo de piña</p>\n\n<p>150 gr. de azúcar</p>\n\n<p>el zumo de un limón</p>\n\n<p>2 claras de huevo.</p>');
INSERT INTO `field_ingredientes` (`pages_id`, `data`) VALUES('1066', '<ul><li>2 huevos.</li>\n	<li>30 gr de espinacas frescas.</li>\n	<li>50 gr de mantequilla.</li>\n	<li>1/ cucharadita de perejil.</li>\n	<li>Queso parmesano rallado.</li>\n	<li>Sal y pimienta.</li>\n</ul>');

DROP TABLE IF EXISTS `field_language`;
CREATE TABLE `field_language` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language` (`pages_id`, `data`, `sort`) VALUES('40', '1020', '0');
INSERT INTO `field_language` (`pages_id`, `data`, `sort`) VALUES('41', '1020', '0');

DROP TABLE IF EXISTS `field_language_files`;
CREATE TABLE `field_language_files` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--admintheme-php.json', '0', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--field-php.json', '1', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--fieldgroups-php.json', '2', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--fields-php.json', '3', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--fieldselectorinfo-php.json', '4', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--fieldtype-php.json', '5', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--fieldtypemulti-php.json', '6', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--functions-php.json', '7', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--inputfield-php.json', '8', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--inputfieldwrapper-php.json', '9', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--modules-php.json', '10', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--pagefile-php.json', '11', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--pageimage-php.json', '12', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--pages-php.json', '13', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--password-php.json', '14', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--process-php.json', '15', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--sanitizer-php.json', '16', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--session-php.json', '17', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--sessioncsrf-php.json', '18', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--wirecache-php.json', '19', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--wirehttp-php.json', '20', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--wiretempdir-php.json', '21', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--core--wireupload-php.json', '22', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--admintheme--adminthemedefault--adminthemedefault-module.json', '23', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypecomments--commentfilterakismet-module.json', '24', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypecomments--commentform-php.json', '25', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypecomments--commentlist-php.json', '26', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypecomments--fieldtypecomments-module.json', '27', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypecomments--inputfieldcommentsadmin-module.json', '28', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypedatetime-module.json', '29', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypefile-module.json', '30', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypefloat-module.json', '31', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypemodule-module.json', '32', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypepage-module.json', '33', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypepagetable-module.json', '34', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtyperepeater--fieldtyperepeater-module.json', '35', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtyperepeater--inputfieldrepeater-module.json', '36', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypeselector-module.json', '37', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypetext-module.json', '38', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypetextarea-module.json', '39', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--fieldtype--fieldtypeurl-module.json', '40', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldasmselect--inputfieldasmselect-module.json', '41', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldbutton-module.json', '42', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldcheckbox-module.json', '43', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldcheckboxes--inputfieldcheckboxes-module.json', '44', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldckeditor--inputfieldckeditor-module.json', '45', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfielddatetime--inputfielddatetime-module.json', '46', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldemail-module.json', '47', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldfieldset-module.json', '48', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldfile--inputfieldfile-module.json', '49', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldfloat-module.json', '50', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldform-module.json', '51', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldhidden-module.json', '52', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldimage--inputfieldimage-module.json', '53', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldinteger-module.json', '54', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldmarkup-module.json', '55', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldname-module.json', '56', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpage--inputfieldpage-module.json', '57', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpageautocomplete--inputfieldpageautocomplete-module.json', '58', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselect-module.json', '59', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselectmultiple-module.json', '60', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpagename--inputfieldpagename-module.json', '61', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetable-module.json', '62', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetableajax-php.json', '63', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpagetitle--inputfieldpagetitle-module.json', '64', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldpassword-module.json', '65', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldradios--inputfieldradios-module.json', '66', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldselect-module.json', '67', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldselectmultiple-module.json', '68', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldselector--inputfieldselector-module.json', '69', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldsubmit--inputfieldsubmit-module.json', '70', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldtext-module.json', '71', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldtextarea-module.json', '72', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--inputfield--inputfieldurl-module.json', '73', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--jquery--jquerywiretabs--jquerywiretabs-module.json', '74', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--languagesupport--languageparser-php.json', '75', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--languagesupport--languagesupport-module.json', '76', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--languagesupport--languagesupportfields-module.json', '77', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--languagesupport--languagesupportpagenames-module.json', '78', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--languagesupport--languagetabs-module.json', '79', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--languagesupport--processlanguage-module.json', '80', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--markup--markuppagefields-module.json', '81', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--markup--markuppagernav--markuppagernav-module.json', '82', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--pagepaths-module.json', '83', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--pagerender-module.json', '84', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processfield--processfield-module.json', '85', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processfield--processfieldexportimport-php.json', '86', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processforgotpassword-module.json', '87', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processhome-module.json', '88', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processlist-module.json', '89', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processlogin--processlogin-module.json', '90', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processmodule--processmodule-module.json', '91', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processmodule--processmoduleinstall-php.json', '92', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpageadd--processpageadd-module.json', '93', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpageclone-module.json', '94', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpageedit--processpageedit-module.json', '95', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpageeditimageselect--processpageeditimageselect-module.json', '96', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpageeditlink--processpageeditlink-module.json', '97', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpagelist--processpagelist-module.json', '98', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpagelister--processpagelister-module.json', '99', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpagesearch--processpagesearch-module.json', '100', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpagesort-module.json', '101', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpagetrash-module.json', '102', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpagetype--processpagetype-module.json', '103', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpageview-module.json', '104', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processpermission--processpermission-module.json', '105', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processprofile--processprofile-module.json', '106', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processrole--processrole-module.json', '107', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processtemplate--processtemplate-module.json', '108', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processtemplate--processtemplateexportimport-php.json', '109', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--process--processuser--processuser-module.json', '110', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--session--sessionhandlerdb--processsessiondb-module.json', '111', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--session--sessionhandlerdb--sessionhandlerdb-module.json', '112', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--session--sessionloginthrottle--sessionloginthrottle-module.json', '113', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--system--systemupdater--systemupdater-module.json', '114', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--modules--textformatter--textformatterentities-module.json', '115', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--templates-admin--debug-inc.json', '116', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1020', 'wire--templates-admin--default-php.json', '117', '[\"\"]', '2016-02-24 18:45:31', '2016-02-24 18:45:31');

DROP TABLE IF EXISTS `field_language_files_site`;
CREATE TABLE `field_language_files_site` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_pass`;
CREATE TABLE `field_pass` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` char(40) NOT NULL,
  `salt` char(32) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;

DROP TABLE IF EXISTS `field_permissions`;
CREATE TABLE `field_permissions` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_personas`;
CREATE TABLE `field_personas` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1024', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1025', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1026', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1027', '1');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1028', '1');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1029', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1030', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1031', '1');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1032', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1033', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1034', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1035', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1036', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1037', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1038', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1039', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1040', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1041', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1042', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1043', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1044', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1045', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1046', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1047', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1048', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1049', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1050', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1051', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1052', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1053', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1055', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1056', '3');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1057', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1058', '1');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1059', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1060', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1061', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1062', '2');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1063', '1');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1064', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1065', '4');
INSERT INTO `field_personas` (`pages_id`, `data`) VALUES('1066', '1');

DROP TABLE IF EXISTS `field_preparacion`;
CREATE TABLE `field_preparacion` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1024', '<p>Poner agua a hervir con cuatro hojas de laurel, y cocer los camarones durante dos minutos exactos. Luego, escurrimos los camarones y los pelamos (podemos guardar las pieles y cabezas para hacer un fumet de marisco). Para componer la ensalada de surimi y camarones en un bol hacemos una vinagreta con un buen chorro de aceite de oliva y la mitad de vinagre, sobre la que iremos echando los ingredientes de la ensalada: la cebolla cortadita en juliana, como se ve en la foto, los camarones pelados enteros, el surimi troceado y el cilantro muy picadito.</p>\n\n<p>Añadimos pimienta recién molida y sal, y removemos un poco para que todos los ingredientes se impregnen bien de la vinagreta, y dejamos la ensalada de surimi y camarones reposar durante cinco minutos antes de servirla.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1025', '<p> </p>\n\n<p><strong>Para la crema de queso</strong></p>\n\n<p>Para hacer la crema de queso de esta receta de risotto cremoso de setas ponemos una olla pequeña al fuego y en ella vertemos la crema de leche y dejamos que empiece a hervir. Entonces, retiramos del fuego, agregamos el queso manchego cortado en trozos pequeños y dejamos reposar hasta que se enfrié.</p>\n\n<p>Una vez frío, colocamos la crema de leche con el queso en el recipiente del túrmix y trituramos el contenido hasta obtener una crema fina. Añadimos sal y pimienta negra al gusto y reservamos.</p>\n\n<p> </p>\n\n<p><strong>Para el risotto cremoso de setas:</strong></p>\n\n<p>Continuamos la preparación de nuestro risotto cremoso de setas y ahora, limpiamos los boletus con un paño húmedo, sin pasarlos por agua, les cortamos el final del pie y troceamos los pequeños (el grande lo reservamos para decorar).</p>\n\n<p>Una vez tengamos limpias las setas o ceps, cortamos 4 en dados pequeños y reservamos el quinto para la decoración.</p>\n\n<p>Ponemos una cacerola al fuego con el caldo de ave para que se vaya calentando y mientras, vamos preparando el resto de los ingredientes de este risotto cremoso de setas.</p>\n\n<p>Pelamos y picamos las chalotas muy finas y en una olla, las sofreímos con un chorrito de aceite de oliva hasta que estén tiernas.</p>\n\n<p>Seguidamente, añadimos los ceps cortados a la sartén y dejamos que se cocinen.</p>\n\n<p>Incorporamos el vaso de vino blanco, dejamos cocer hasta que éste se evapore y seguidamente le añadimos el arroz carnaroli.</p>\n\n<p>Removemos lo que será nuestro risotto cremoso de setas con una cuchara de madera o con una espátula y vamos añadiendo el caldo de ave poco a poco, removiendo constantemente, dejando que se absorba por completo cada cazo de caldo antes de añadir más y repetiremos el proceso así hasta que el arroz esté al dente.</p>\n\n<p>Unos segundos antes de retirar nuestro risotto cremoso de setas del fuego, le incorporamos la mantequilla, mezclando con una espátula, y rectificamos de sal.</p>\n\n<p>Calentamos de nuevo la crema de queso que tenemos reservada, repartimos el risotto en los platos de servir y, alrededor del risotto de setas, añadimos unas cucharadas de crema de queso.</p>\n\n<p>Con la ayuda de una mandolina o un corta fiambres laminamos muy fino el cep grande que tenemos reservado, colocamos las láminas en crudo por encima del risotto cremoso de setas y decoramos con un poco de perejil picado muy fino.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1026', '<p>Colocamos el hielo en la jarra, echamos el puñado de hojas de menta bien lavadas, el zumo de limón recién exprimido y colado (sobre todo para que no caigan los pipos) y cubrimos con agua. No debemos echar agua hasta arriba, pues falta el zumo de la granada.</p>\n\n<p>Exprimimos una granada en el momento. Para ello, la cortamos por la mitad y, apretándola con las manos, pues con un exprimidor no se puede hacer, le sacaremos todo el jugo que podamos.</p>\n\n<p>Para sacar el mayor jugo posible de la granada, es importante que esta no esté muy fría, mejor si está a temperatura ambiente.</p>\n\n<p>Mezclamos todo bien, y lista.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1055', '<p>Pon los huevos en un bol, bátelos con la varilla e incorpora el azúcar poco a poco.</p>\n\n<p>Trocea el chocolate y la mantequilla, ponlos en un bol y deja que se fundan al baño maría removiendo con cuidado. Una vez fundido, añade al bol de los huevos y remueve bien.</p>\n\n<p>Por otro lado, mezcla la harina con las nueces peladas y troceadas. Añade a la mezcla de los huevos. Remueve bien y coloca todo en un recipiente apto para horno untado de mantequilla y harina. Hornea a 180ºC durante 40 minutos. Deja templar para desmoldar.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1027', '<p>Ponemos dentro del recipiente tres o cuatro cubitos de hielo y los hacemos girar dentro, con ayuda de una varilla mezcladora. De este modo refrescaremos el vaso para el gin tonic. A continuación, desechamos esos hielos y escurrimos el agua que hayan soltado.</p>\n\n<p>Estrujamos la peladura de lima o limón y la restregamos por el borde del vaso. Echamos dentro esa piel y ponemos otros cuatro o cinco cubitos de hielo dentro de la copa para el gin tonic.</p>\n\n<p>Añadimos ginebra durante tres segundos. Esa es la cantidad exacta de alcohol, según los entendidos, que necesita un gin tonic. Otras versiones dicen que se debe poner un tercio del vaso y hay quien prefiere poner la cantidad según su gusto.</p>\n\n<p>Por último rellenamos con tónica y removemos un poco con la varilla, para que las burbujas presten viveza a la copa. Ya podemos disfrutar de un buen trago de gin tonic.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1051', '<p>En una picadora picamos las almendras y  las nueces. El tamaño debe ser similar o más pequeño que un grano de pimienta. Colocamos todos los frutos secos en un bol grande y añadimos 3 cucharadas de azúcar y la canela molida. Removemos todo muy bien para que se mezclen los sabores. Este será el relleno del baklava, es imposible que estos pastelillos no esten buenos.</p>\n\n<p>Derretimos la mantequilla al baño maría o en el micro hasta que quede líquida y preparamos la pasta filo en una superficie cómoda para trabajar. Necesitaremos al menos 12 hojas de pasta filo.</p>\n\n<p>Engrasamos un recipiente ayudados con un pincel de silicona, en mi caso he elegido una fuente típica de hacer bizcochos de 30 x 40 cm. Una vez engrasado empezamos a colocar las hojas de pasta, untándolas con mantequilla una a una. Colocamos 2 hojas juntas como base y rellenamos con una capa de frutos secos. Seguimos colocando capas de pasta filo, capas de relleno hasta que tan solo nos queden 2 láminas que serán la cubierta del pastel. La última capa tambien la pincelamos con mantequilla. Presionamos bien para que quede compacto y acto seguido enfriamos en la nevera durante 30 minutos.</p>\n\n<p>Sacamos la fuente y cortamos cuidadosamente el pastel con un cuchillo bien afilado y largo en forma de rombos o cuadraditos, depende de la fuente que uses.</p>\n\n<p>Precalentamos el horno a 190º durante 5 minutos e introducimos la fuente en el horno en la bandeja del medio, con calor arriba y abajo durante 30 minutos.</p>\n\n<p>Preparamos el almíbar mientras la baklava se está haciendo. Calentamos en un cazo un vaso de agua junto con el agua de azahar y cuando hierva añadimos una cucharada de zumo de limón, canela, cáscara del limón, los clavos de olor y 5 cucharadas de azúcar. Removemos con una cuchara de madera durante 15 minutos y cuando esté listo dejamos enfriar. Colamos y reservamos para después.</p>\n\n<p>Sacamos los baklavas del horno y los bañamos con el almíbar. Picamos los pistachos y los espolvoreamos por encima. Dejamos enfriar durante 2 horas antes de servirlos. Es de por si un postre muy nutritivo, así que un poco de café o un buen té de menta como acompañamiento le quedan perfectos.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1028', '<p>El primer paso para disfrutar de un smoothie de banana consiste en pelar los plátanos y ponerlos cortados en trocitos en el vaso de la licuadora con el resto de ingredientes; es decir, con el hielo, el azúcar y la leche (la leche, mejor si está fría).</p>\n\n<p>El segundo y último paso consiste simplemente en licuar todos los ingredientes de este smoothie de banana hasta que estén perfectamente mezclados y consigas la cremosa textura propia de estos batidos de frutas: ni muy denso (esto sería una crema de frutas), ni demasiado fluido (ya que entonces, estaríamos hablando de un zumo de plátano).</p>\n\n<p>Sirve tu smoothie de banana inmediatamente y ¡a disfrutar! Si no vas a tomar el batido de plátano en el momento, guárdalo en la parte inferior del congelador.</p>\n\n<p>Para decorar las copas en las que vayas a servir el smoothie de banana, humedece el borde y pósalas sobre un montoncito de azúcar. También es interesante echar unos fideos de chocolate sobre cada copa de batido de plátano: le da color y un contraste de sabor (plátano con chocolate) que siempre es un acierto.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1029', '<p>Colocamos el café helado, que tendremos hecho todo lo cargado que nos guste, en una jarra.</p>\n\n<p>Trituramos una buena cantidad de cubitos de hielo y vamos repartiendo la mitad del hielo triturado entre los vasos en que vamos a servir el granizado de café.</p>\n\n<p>La otra mitad de los cubitos de hielo triturado, la vamos a poner dentro de la jarra con el café helado. Servimos el café granizado sobre los vasos con hielo frappé y les añadimos un poquitín de nata líquida. Espolvoreamos cada granizado de café con un poquito de cacao en polvo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1030', '<p>Para preparar este refrescante té helado con limón, lo primero que debemos hacer es poner al fuego la mitad del agua en una tetera, o en su defecto, en un cazo pequeño.</p>\n\n<p>Cuando comience a hervir, echamos el agua sobre los saquitos de té (si es una tetera, tan solo tendremos que introducir los saquitos dentro). Tapamos, y dejamos que repose durante unos 5 minutos.</p>\n\n<p>Transcurrido el tiempo, continuaremos preparando el té helado con limón, echando el agua de la tetera (ya sin las bolsitas), en una jarra. Añadimos el azúcar (la cantidad irá con gustos), el zumo de limón, el resto del agua fría, y removemos. A continuación, metemos la jarra en el frigorífico y dejamos hasta que se enfríe.</p>\n\n<p>Cuando esté bien fresquito, le añadimos una cantidad generosa de hielo, y ya podremos disfrutar de este té helado con limón.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1031', '<p>Para preparar este cremoso chocolate a la taza empezaremos por cortar en trocitos el chocolate negro y reservándolo para después.</p>\n\n<p>Ahora, en un cazo vertemos la leche y ponemos a calentar. Cuando esté templada, añadimos el chocolate troceado y removemos bien con la ayuda de unas varillas o de una cuchara de madera.</p>\n\n<p>Cuando el chocolate comience a derretirse, añadimos el azúcar y la maicena y ya sólo nos quedará remover hasta que nuestro chocolate a la taza adquiera la textura deseada.</p>\n\n<p>Retiramos del fuego y servimos el chocolate a la taza casero bien caliente. </p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1032', '<p>En primer lugar, una vez cortadas las pechugas en el los filetes y tamaños que más nos convenga (eso sí, conviene que sean finitos), las vamos a salpimentar y las vamos a pasar primero por harina y las vamos a golpear bien para que no nos queden grumos. Luego, las pasaremos por huevo batido, y las reservaremos.</p>\n\n<p>En una sartén, calentaremos el aceite de oliva, y cuando alcance bastante temperatura, echaremos las pechugas enharinadas y las mantendremos hasta que estén doradas. En ese punto, las retiramos del fuego.</p>\n\n<p>El segundo paso consiste en hacer la salsa. Para ello, empezaremos deshaciendo la mantequilla en una sartén. Luego, añadiremos la harina, removeremos, y aplastaremos hasta que no haya grumos. Habremos lo grado lo que se conoce en cocina como roux blanco.</p>\n\n<p>Logrado este punto, añadiremos el caldo caliente en tandas, el vino blanco, el zumo de los dos limones, lo integraremos todo, salpimentaremos al gusto, y lo trabajaremos hasta que reduzca aproximadamente hasta la mitad.</p>\n\n<p>Cuando tengamos la salsa típica de las pechugas de pollo a la francesa, sumergimos en ellas las pechugas de pollo enharinadas y fritas, las tapamos ligeramente, y dejamos que terminen de hacerse durante unos 20 minutos más.</p>\n\n<p>Servimos las pechugas de pollo a la fracesa con la salsa y un poco de perejil picado fresco por encima.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1033', '<p>Una hora antes de comenzar a preparar los solomillos de pavo asado, en un bol pondremos la miel, la salsa de soja, la mostaza y un par de cucharadas de aceite de oliva.</p>\n\n<p>Mezclamos bien con un tenedor y cuando todos los ingredientes del adobo estén bien integrados, ponemos el solomillo en el bol y lo impregnamos bien. Tapamos el bol con papel de film y dejamos que repose durante una hora.</p>\n\n<p>Mientras el solomillo de pavo reposa en el adobo, pelamos y cortamos la cebolla en juliana fina y los pimientos en dados. Lo colocamos todo en el fondo de la bandeja de cristal apta para horno en la que haremos nuestro solomillo de pavo asado.</p>\n\n<p>Regamos la cama de cebolla con un hilito de aceite de oliva, salpimentamos, ponemos un chorrito de vino blanco dulce y otro chorrito de agua, y cuando haya terminado el tiempo de reposo del solomillo, lo colocamos encima, reservando el jugo de la maceración para añadirlo al solomillo de pavo más adelante.</p>\n\n<p>Introducimos la bandeja con la carne de pavo en el horno previamente calentado a 200ºC, y dejamos 15 minutos.</p>\n\n<p>Pasado ese tiempo, sacamos, regamos el solomillo con el resto del jugo de la maceración que tenemos reservado, damos la vuelta a la carne y lo introducimos de nuevo en el horno durante otros 15 minutos más.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1034', '<p>Antes de comenzar a preparar el solomillo al horno, vamos a dejar precalentando el horno a 200ºC y nos hacemos con una buena cazuela, en la que podamos acomodar los solomillos de cerdo.</p>\n\n<p>Limpiamos la carne de cerdo, quitando el exceso de grasa y la telilla que suele cubrirla. Lavamos las piezas bajo el chorro de agua fría y las secamos muy bien con papel absorbente.</p>\n\n<p>Salpimentamos al gusto los trozos de carne que vamos a emplear para hacer los solomillos al horno y reservamos.</p>\n\n<p>Colocamos la cazuela al fuego, con un poquito de aceite de oliva. Cuando esté caliente, incorporamos los solomillos y los doramos por todas partes, para que la carne quede bien sellada y conserve todos sus jugos dentro durante el asado.</p>\n\n<p>Unos cinco minutos bastarán para que la carne esté en su punto y podamos meter la misma cazuela con los solomillos al horno. Dejamos que se asen durante veinte minutos, regándolos con sus propios juguitos.</p>\n\n<p> </p>\n\n<p>Transcurrido el tiempo de asado, sacamos la cazuela y tapamos con un trozo de papel albal. Dejamos que el solomillo al horno repose durante diez minutos. Colocamos los solomillos en una bandeja y lo cortamos en rodaja. Regamos con la salsa desglasada con un poquito de agua o caldo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1035', '<p>Una vez que tengamos la pieza de carne limpia y preparada por el carnicero, para hacer un rico solomillo con hojaldre, colocamos una sartén al fuego con un poquito de aceite de oliva.</p>\n\n<p>Salpimentamos la carne de cerdo al gusto y la doramos por todas partes para sellarla. Sacamos de la sartén y reservamos.</p>\n\n<p>Nos ponemos manos a la obra con los champiñones para el solomillo con hojaldre. Los limpiamos con un paño de cocina, quitamos la parte más terrosa del tallo y cortamos los hongos en cubitos.</p>\n\n<p>Pelamos las cebollitas francesas y el diente de ajo y hacemos un picadito fino, que ponemos a pochar en un poquito de aceite de oliva. Tras cinco minutos a potencia media, incorporamos los champiñones al pochado. Damos otros diez minutos de cocción y apartamos.</p>\n\n<p>Dejamos que todos los ingredientes se enfríen antes de pasar al enrollado del solomillo con hojaldre, para que la lámina hojaldrada no se reblandezca. Extendemos la mostaza de Dijon por toda la pieza de carne e incorporamos el foie gras al pochado de chalotas y champiñones.</p>\n\n<p>Removemos bien estos ingredientes, hasta conseguir una pasta con cierta entidad. Elegimos una bandeja de horno, colocamos un papel engrasado sobre ella y extendemos la masa de hojaldre.</p>\n\n<p>Aplicamos sobre la lámina de hojaldre una capa de la mezcla que hemos hecho con el foie gras y colocamos encima el solomillo. Recubrimos la pieza con más pasta de foie y champiñones y cerramos la masa sobre el rulo de cerdo.</p>\n\n<p>Sellamos bien el solomillo con hojaldre y retiramos lo que sobre de los extremos, dejándolos también sellados. Pintamos con huevo batido.</p>\n\n<p>Llevamos el solomillo con hojaldre al horno precalentado a 200ºC. Colocamos la bandeja en el centro del horno y cocinamos durante veinte minutos o hasta que esté dorado y crujiente. Sacamos el solomillo con hojaldre del horno y dejamos reposar diez minutos antes de cortar.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1036', '<p>Ponemos a precalentar el horno a 170ºC, y mientras coge temperatura, hacemos un majado de mortero que dará sabor a la carne.</p>\n\n<p>Para eso, en un mortero, ponemos 3 ajos pelados y cortados a la mitad, dos ramitas de perejil picadas y media cucharadita de sal.</p>\n\n<p>Trituramos todo hasta obtener una pasta, la pasamos a un cuenquito donde tendremos la manteca de cerdo reblandecida (si lo prefieres, puedes sustituirla por mantequilla o incluso por aceite de oliva) y mezclamos con un tenedor para que se integre todo a la perfección.</p>\n\n<p>Con esta pasta, embadurnamos la pierna de cordero y la ponemos en una bandeja de barro. La regamos con el vino, añadimos medio vaso de agua y repartimos sobre ella las ramitas de romero partidas en trocitos y las hojas de laurel.</p>\n\n<p>Llevamos la pierna de cordero al horno, bajamos la temperatura a 165ºC y la dejamos los primeros 30 minutos.</p>\n\n<p>Mientras, preparamos las patatas panaderas. Pelamos las patatas y las cortamos en rodajas no muy gruesas. Hacemos lo mismo con la cebolla y lo ponemos todo junto en una fuente.</p>\n\n<p>Ahora, en un mortero ponemos los otros 2 dientes de ajo pelados y partidos a la mitad, la ramita de perejil, un poco de sal y machacamos todo.</p>\n\n<p>Untamos con la masa las patatas y la cebolla, regamos con un hilito de aceite, condimentamos con pimienta y reservamos.</p>\n\n<p>Transcurridos los primeros 30 minutos, sacamos la pierna del cordero del horno, le damos la vuelta, la regamos con los jugos que haya soltado y repartimos a su alrededor las patatas panaderas y la cebolla.</p>\n\n<p>Si vemos que se ha consumido todo el agua, añadimos un poco más (o caldo), pues es muy importante que no se quede seca la carne.</p>\n\n<p>Volvemos a meter la pierna de cordero en el horno y dejamos que se cocine todo durante al menos otros 40 minutos más, o hasta que comprobemos que la carne de cordero está hecha y las patatas panaderas cocinadas.</p>\n\n<p>Si vemos que la pierna de cordero se nos dora demasiado pero que las patatas y la cebolla aún les queda un poco de tiempo, puedes tapar la fuente con papel de aluminio o apagar la resistencia superior del horno y dejar que termine el tiempo de horneado recomendado.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1037', '<p>Por un lado, ponemos a precalentar el horno a 180ºC, y por otro, calentamos también una sartén antiadherente con un poquito de aceite de oliva.</p>\n\n<p>Mientras coge temperatura, pelamos, descorazonamos y troceamos las manzanas. Las echamos a la sartén, condimentamos con un poquito de canela en polvo, damos unas vueltas con una cuchara de palo y mantenemos a fuego medio-bajo unos 4 minutos.</p>\n\n<p>Pasado ese tiempo, añadimos las pasas y las nueces partidas en trocitos a la sartén. Cocinamos otros 4 minutos más y retiramos del fuego.</p>\n\n<p>Ahora, procedemos a montar las pechugas de pavo rellenas. Para eso, extendemos las pechugas de pavo en una superficie lisa y untamos su interior con un poquito de aceite. Salpimentamos y repartimos el relleno que tenemos en la sartén.</p>\n\n<p>Enrollamos las pechugas de pavo rellenas y las atamos cuidadosamente con hilo de cocina para que mantengan su forma.</p>\n\n<p>A continuación, volvemos a poner al fuego la sartén en la que hicimos el relleno del pavo, añadimos un par de cucharadas de aceite, y cuando esté caliente, incorporamos las pechugas de pavo rellenas y las sellamos a fuego fuerte.</p>\n\n<p>Pasamos las pechugas de pavo rellenas a una fuente apta para horno, las regamos con el caldo de pollo y las horneamos durante unos 10 minutos.</p>\n\n<p>Pasado ese tiempo, sacamos las pechugas rellenas del horno, las regamos con la sidra, colocamos una ramita de tomillo y otra de romero encima de cada una ellas y volvemos a hornear otros 10 minutos más (o hasta que comprobemos que están cocidas, pues este punto depende mucho del grosor de las pechugas).</p>\n\n<p>Pasado ese tiempo, sólo nos queda pasar la salsa que hay en la fuente a un cacito, llevarla al fuego y ligarla con la maicena, removiendo durante unos minutos con una cuchara de palo. Retiramos la cuerda, fileteamos las pechugas de pavo rellenas, las servimos acompañadas de la salsa, y listo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1038', '<p>Pelamos las patatas, la cortamos en láminas y las freímos a fuego medio en una sartén con un generoso chorro de aceite.</p>\n\n<p>Entre tanto, picamos las cebolletas en brunoise y las añadimos a la sartén.</p>\n\n<p>Por otro lado, batimos los huevos con un poquito de sal y reservamos.</p>\n\n<p>Cuando las patatas estén blandas, con la ayuda de una espumadera, las pasamos a un escurridor para que eliminen el exceso de aceite, sazonamos y las pasamos al bol con el huevo batido.</p>\n\n<p> </p>\n\n<p>Removemos hasta conseguir una mezcla homogénea y reservamos.</p>\n\n<p>En una sartén antiadherente echamos un poquito de aceite y cuando esté bien caliente, vertemos la masa de la tortilla de patatas y la cuajamos por ambos lados.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1039', '<p>Lo primero que haremos será poner las virutas de beicon en una sartén al fuego y dejar que se frían en su propia grasa. Luego lo apartamos y dejamos que suelten el exceso sobre papel absorbente.</p>\n\n<p>Separamos las yemas de las claras de dos huevos y montamos las claras a punto de nieve. Ahora unimos sus dos yemas a los otros dos huevos, agregamos la nata y batimos, hasta que queden bien integrados.</p>\n\n<p> </p>\n\n<p>Incorporamos al batido de huevos la mozzarella troceada en cubitos, las virutas de beicon, las hierbas, la crema de rábano y la mostaza y salpimentamos el suflé a nuestro gusto.</p>\n\n<p>Mezclamos bien todos estos ingredientes y les añadimos las claras a punto de nieve, con movimientos envolventes y despacito, para que no se baje.</p>\n\n<p>Untamos con mantequilla cuatro moldes individuales y repartimos el suflé. Llevamos al horno durante media hora o hasta que veamos que está doradito por arriba. Sacamos y a comer.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1040', '<p>Comenzamos mezclando la carne con la cebolleta picada muy finamente y dos cucharadas de pan rallado, la yema del huevo crudo, una cucharada de perejil bien picado, la sal, la pimienta negra y la nuez moscada (al gusto). Amasamos bien la preparación y la repartimos en cuatro porciones. Reservamos.</p>\n\n<p>Nos humedecemos las manos, y cogemos una porción de carne, la ahuecamos y le colocamos un huevo cocido en el centro.</p>\n\n<p>Cerramos de forma que quede como una croqueta rellena con el huevo en su interior.</p>\n\n<p>Pasamos la carne por la clara de huevo batida y por el pan rallado, las freímos en una sartén con un buen chorreón de aceite de oliva, hasta que estén bien doradas. Una vez fritas, las colocamos sobre papel absorbente y listo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1041', '<p>Picando muy mucho la cebollita, y pochándola con su buen chorro de aceite de oliva en una cazuela. Sólo cuando esté transparente, añadiremos el cordero cortatido en taquitos y salpimentado, y lo doraremos bien subiendo el fuego al máximo.</p>\n\n<p> </p>\n\n<p>Unos 5 minutos después, nuestra receta de cuscús de cordero al estilo mozárabe nos pedirá que añadamos las pasas sultanas junto con el vino dulce. Seguidamente, echaremos la harina para que espese la salsaita, y el jengibre. Dejaremos cocer unos 15 minutos más a fuego bajo.</p>\n\n<p> </p>\n\n<p>En una cazuela aparte, con un vaso de agua, la mantequilla y la pastillita de caldo de ave, cocemos el cuscús, y lo dejamos cocer, con la tapa puesta. Tras 5 minutos, cuando el cuscús haya absorbido el agua, lo mezclaremos con la salsa, y servís el cuscús de cordero al estilo mozárabe muy calentito.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1042', '<p>La ensalada de perdiz escabechada me remonta a mis años mozos, cuando visitaba asiduamente un pueblecito de La Mancha y siempre alguien abría un bote de perdiz y te alegraba la vida con un plato riquísimo.</p>\n\n<p>Hoy os dejo una de aquellas deliciosas recetas de ensalada de perdiz escabechada y comenzamos por lavar el bouquet de lechugas variadas, escurrir bien y secar las hojas. Troceamos y disponemos en una fuente para presentación, formando un lecho.</p>\n\n<p>Abrimos el bote de perdiz escabechada, sacamos el ave y rociamos las lechugas con un poquitín del escabeche. Deshuesamos la perdiz y desmenuzamos su carne. Acomodamos los trozos sobre la cama de lechugas.</p>\n\n<p>En un sartén tostamos un poquito los piñones y los repartimos por la ensalada de perdiz escabechada. Añadimos los arándanos y las frambuesas ya limpios y preparamos la vinagreta.</p>\n\n<p>Para ello, ponemos en un cuenco un chorreón de aceite de oliva, un poquito de vinagre y salpimentamos al gusto. Batimos con tenedor hasta conseguir una emulsión con la que regamos esta receta de perdiz en escabeche y a saborearla.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1043', '<p>Para empezar a elaborar las tortas de trigo tenemos que tamizar la harina para que quede mucho más fina y luego no salgan grumos.</p>\n\n<p>Colocamos la harina tamizada en un bol y vertemos sobre ella la sal y mezclamos bien. Agregamos el aceite de girasol y con las manos lo mezclamos todo hasta obtener una textura arenosa.</p>\n\n<p>A continuación, vamos añadiendo el agua muy poco a poco mientras vamos mezclando todo con las manos.Trabajamos la masa de las tortas de trigo unos cinco minutos una vez que hayamos integrado el agua por completo.</p>\n\n<p>Hacemos bolas pequeñas de masa y las aplastamos con la ayuda de un rodillo. Calentamos en una sartén cada una de las bolas aplastadas hasta que estén doradas, damos la vuelta y doramos por el otro lado.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1044', '<p>Comenzamos por pelar la cebolla y los tomates, a los que también vamos a retirar las pepitas. Abrimos los pimientos, retiramos las semillas y quitamos las nervaduras.</p>\n\n<p>Cortamos todas las verduras en dados. Por supuesto que doy por sentado que hemos lavado todas las hortalizas, claro.</p>\n\n<p>Colocamos una buena sartén al fuego y añadimos un chorreón generoso de aceite de oliva. Cuando haya cogido temperatura, incorporamos la cebolla y, en cuanto cambie de color, añadimos los pimiento y dejamos pochar cinco minutos.</p>\n\n<p>Transcurrido ese tiempo, agregamos a la sartén el calabacín y la berenjena y les damos unos ocho minutitos de cocción y ese es el momento en el que llega a la sartén el tomate.</p>\n\n<p>Sazonamos el sofrito de verduras y probamos de acidez. Si fuera necesario podemos corregir con un poco de azúcar.</p>\n\n<p>Dejamos que la sanfaina se cocine durante unos veinte minutos más a fuego lento y ya la tenemos a punto de caramelo para servirla con lo que más nos guste.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1045', '<p>Empezamos nuestra rica receta de macarrones a la puttanesca llevando una olla con agua salada al fuego y una vez que rompa a hervir, le echamos la pasta y dejamos que se haga según nos indique el fabricante.</p>\n\n<p>Mientras se nos hacen los macarrones, en una sartén prepararemos la puttanesca o la salsa putanesca y para eso, añadiremos un chorrito de aceite de oliva y freiremos ligeramente la guindilla cortada en rodajitas junto con los ajos laminados.</p>\n\n<p>Cuando vaya a tomar un poco de color los ajos le añadiremos el tomate frito junto con las aceitunas y una cucharadita de orégano.</p>\n\n<p>Una vez ya tengamos los macarrones hechos, los escurrimos y se los añadimos a la sartén donde tenemos nuestra salsa puttanesca.</p>\n\n<p>Removemos un poco y retiramos del fuego. Espolvoreamos ahora el queso sobre los macarrones a la puttanesca y listo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1046', '<p>Para elaborar una estupenda ensalada caprese de pasta, lo primero que haremos será poner a cocer las espirales de pasta, en una cazo con agua y sal, tanto tiempo como indique el envase del fabricante. Una vez al dente, escurrimos la pasta y la reservamos.</p>\n\n<p>A continuación, lavamos bien los tomates, y los cortamos en varios trozos del tamaño de un bocado.</p>\n\n<p>Seleccionamos 4 de las 12 hojas de albahaca, y hacemos una majada en un mortero, con un chorrito de aceite de oliva y una pizca de sal.</p>\n\n<p>El otro gran ingrediente de nuestra ensalada caprese de pasta, el queso mozzarella, lo rallaremos con la ayuda de un rallador de cocina.</p>\n\n<p>A la hora de emplatar nuestra apetitosa ensalada caprese de pasta, crearemos un lecho de espirales en la ensaladera, seguido de una capa de queso mozzarella rallado, los trocitos de tomate y las hojas de albahaca restantes. Finalmente, regamos con la majada de aceite y albahaca picada, espolvoreamos un poco de orégano.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1047', '<p>Colocamos al fuego el wok donde vamos a preparar los fideos chinos con gambas y añadimos dentro un poco de aceite de oliva.</p>\n\n<p>Cuando el aceite esté caliente, agregamos dentro la cebolla cortada en juliana y el pimiento verde, cortado también en juliana. Salteamos ambas verduras.</p>\n\n<p>Añadimos las gambas peladas y un poco de salsa de soja. Mezclamos todo bien.</p>\n\n<p>Incorporamos los fideos chinos y añadimos agua hasta cubrirlos. Cocinamos a fuego fuerte hasta que el caldo se haya consumido.</p>\n\n<p>Salpimentamos los fideos chinos con gambas al gusto y mezclamos todo muy bien. Servimos con un poco de salsa de soja por encima.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1048', '<p>En un cuenquito ponemos las hojas de gelatina, añadimos un chorro de leche y dejamos que se hidraten.</p>\n\n<p>Entre tanto, con unas varillas eléctricas empezamos a montar la nata líquida (que tendremos muy fría) y cuando esté a medio montar, vamos añadiendo el azúcar cucharada a cucharada sin dejar de batir y terminamos de montar la nata. Reservamos.</p>\n\n<p>Retomamos el cuenquito con la gelatina y si aún no está diluida, lo llevamos un par de segundos al microondas. Removemos hasta que se disuelva por completo y la ponemos en un bol.</p>\n\n<p>Añadimos al bol los yogures (yo los puse de sabor a limón), lo mezclamos bien y lo añadimos al recipiente donde tenemos la nata montada con el azúcar. Mezclamos con movimientos envolventes (bien con una espátula de cocina o con unas varillas eléctricas a muy baja potencia) hasta conseguir una mezcla homogénea y sin grumos.</p>\n\n<p>Pincelamos un molde con un poquito de aceite de girasol y vertemos en él la mezcla del pastel de bavarois que acabamos de preparar. Tapamos con papel de film y guardamos en la nevera hasta que cuaje por completo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1049', '<p>Agitamos el recipiente de la nata, para que toda la grasa se mezcle bien, la echamos en un bol grandecito y, con ayuda de las varillas de la batidora, la batimos hasta que la veamos bien cremosa.</p>\n\n<p>Añadimos el azúcar a la crema de nata poco a poco, sin parar de batir, hasta que todo esté bien mezclado y el azúcar disuelta.</p>\n\n<p>Añadimos ahora la leche condensada, poco a poco y, como antes, sin dejar de batir.</p>\n\n<p>Terminamos añadiendo el extracto de vainilla y batimos hasta que tengamos una crema fría y homogénea.</p>\n\n<p>Si tenemos heladera, la usaremos para terminar este helado. Pero si no es así, echamos la crema de nata en un bol con tapadera, y lo metemos en el congelador.</p>\n\n<p>Sacaremos el helado del congelador cada 30 minutos, para removerlo y que no forme cristales que harían desagradable comer el helado.</p>\n\n<p>Cuando veamos que el helado tipo sundae tiene la consistencia deseada, será el momento de montar el helado como más nos guste... A mi me encanta con sirope de chocolate, nata montada y trocitos de oreo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1050', '<p>Está claro que las cerezas deben ir deshuesadas. Cuando yo hago este postre, invito a mis nietos a que colaboren y les lavo muy bien las manitas y se lo pasan bomba sacando las semillitas de la fruta.</p>\n\n<p>Una vez que tengamos todas las cerezas sin hueso y sin rabito, comenzamos con la elaboración de estas cerezas al vino tinto. Para ello, colocamos en una cacerolita el vino tinto y el azúcar.</p>\n\n<p>Llevamos el recipiente al fuego y dejamos que hierva hasta conseguir un jarabe más consistente al que añadiremos las cerezas limpias. Dejamos cocinar durante media horita.</p>\n\n<p>Una vez transcurrido el tiempo de cocción de las cerezas al vino, sacamos la fruta con ayuda de una paleta y las colocamos en un recipiente, mientras dejamos que el jarabe siga cociendo, a fuego lento, durante otros veinte minutillos.</p>\n\n<p>Cuando haya pasado este tiempo y el jarabe haya reducido y espesado, lo apartamos y rociamos con él las cerezas. Dejamos atemperar y llevamos a la nevera.</p>\n\n<p>Antes de servir las cerezas al vino tinto tendremos que dejarlas unas tres horitas y media en el frigo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1052', '<p>En una sartén antiadherente, ponemos un chorrito de aceite y mientras se calienta, laminaremos la berenjena para hacer la moussaka.</p>\n\n<p>Cuando aceite esté caliente, sofreímos las láminas de berenjena unos minutos por cada lado hasta que estén doradas. Sacamos sobre una fuente y reservamos.</p>\n\n<p>Ahora, en la misma sartén, preparamos el relleno de la musaka. Ponemos un par de cucharas más de aceite y pochamos con una pizca de sal, la cebolla cortada en brunoise. Cuando comience a estar transparente, añadimos los ajos picados finos y los tomates también pelados y cortados en brunoise. Dejamos que se cocine a fuego un poco fuerte unos 5 minutos.</p>\n\n<p>Agregamos la carne picada, salpimentamos, ponemos un pelín de nuez moscada, bajamos a fuego medio y dejamos que se haga unos 20 minutos más.</p>\n\n<p>Ya sólo nos queda montar la musaca. En un molde engrasado, empezamos a alternar una capa de berenjena, otra de carne picada y queso rallado hasta terminar con los ingredientes.</p>\n\n<p>Cubrimos la moussaka con salsa bechamel y metemos en el horno calentado a 175ºC unos 35 minutos.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1053', '<p>Tamizamos la harina sobre un bol. Templamos el agua con cuidado de que no llegue a quemar (pues mataríamos la levadura), lo justo para disolver la levadura con facilidad.</p>\n\n<p>Volvamos el agua en el bol junto con el resto de ingredientes (aceite de oliva, sal y orégano).</p>\n\n<p> </p>\n\n<p>Mezclamos con una mano limpia hasta formar una masa. Amasamos la bola inicial hasta que la harina y los líquidos estén totalmente integrados. Con unos 10 minutos, bastará.</p>\n\n<p>Dejamos fermentar la bola de masa en un bol limpio y tapada. Debe estar en un ambiente cálido.</p>\n\n<p>Cuando duplique su tamaño aproximadamente, sacamos la masa del bol, amasamos durante cinco minutos, y estiramos la masa. Le damos forma rectangular.</p>\n\n<p>Rellenamos la masa y horneamos. Cuando tengamos la masa estirada, empezaremos a precalentar el horno a 200ºC.</p>\n\n<p>Mientras rellenaremos la masa no como si fuera una pizza, sino más bien como si se tratara de un empanadilla gigante; o sea, colocando los ingredientes en una mitad y dejando márgenes suficientes, para luego cerrar y sellar con la masa de los bordes.</p>\n\n<p>El relleno consistirá en una capa de provolone, otra de jamón, otra de pimientos de piquillo, otra de huevo cocido y otra de emmental; todo bien picado.</p>\n\n<p>Cuanto tengamos el calzone relleno y cerrado, lo metemos en el horno durante 20 minutos a 200ºC, y listo.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1056', '<p>Empezaremos preparando el condimento para el sushi. En una recipiente pequeño calentamos el vinagre con el azúcar y la sal y mezclamos hasta que se disuelva. No debe hervir, solo calentarlo un poco. Después lo dejamos enfriar. Hacemos los cuatro remojos al arroz. Lo dejaremos una hora escurrido.</p>\n\n<p>Ponemos el arroz en una olla y añadimos el agua. Dejamos reposar 10 minutos. Después lo ponemos sobre el fuego fuerte y cuando empiece a hervir lo tapamos, bajamos el fuego y dejamos 10 minutos más. Cuando termine apartamos, y sin destapar dejamos 15 minutos más.</p>\n\n<p>El aguacate lo cortamos en tiras. Después los palitos de cangrejo, el pepino lo pelamos y partimos en tiras (quitando las semillas). Una vez preparados todos los ingredientes continuaremos.</p>\n\n<p>Ponemos sobre la esterilla media lámina de alga nori. Después colocamos el arroz, que quede un poco suelto, no mucho. Las semillas de sésamo y cogemos de un extremo para dar la vuelta.</p>\n\n<p>Ponemos los ingredientes a lo largo. Y enrrollamos. Una vez enrollado y que quede bien apretado partimos en unos 6 trozos.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1057', '<p>Si las almendras no están tostadas , tuesta las almendras fileteadas en el horno y resérvalas. </p>\n\n<p>En un bol, monta las cuatro claras a punto de nieve y añade el azúcar hasta obtener un merenge. Después, añade las almendras y el licor de almendras,  remueve con suavidad. En otro bol, semimonta la nata y después añade poco a poco a la mezcla anterior sin dejar de batir. Introduce la mezcla al congelador durante una hora.</p>\n\n<p>Después, la sacamos y la batimos con una varila suavemente para romper los cristales de hielo.Metemos de nuevo al congelador, esperamos 30 minutos, lo sacamos y lo volvemos a batir. Repetimos este paso, al menos, dos veces más. De hecho, cuantas más veces repitamos este paso más cremoso quedará el helado.</p>\n\n<p>Por último, dejamos reposar el helado durante, al menos, cuatro horas más antes de servir. </p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1058', '<p>Mezclar los dos primeros ingredientes en un vaso mezclador con hielo.</p>\n\n<p>Verter sobre un vaso de tubo y posteriormente añadir el Sprite ó SevenUp, según se prefiera. Decorar con una rodaja de limón u otra fruta.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1059', '<p>Calienta el aceite de oliva en una cazuela profunda. Saltea el jengibre cortado y el ajo en la cazuela. Baja el fuego y retira el jengibre y el ajo.  Añade la sopa de pollo y el caldo dashi a la cazuela y ponlo a hervir.<br />\nAñade el azúcar, la sal, el sake, y la salsa de soja en la sopa. Resérvala.<br />\nMientras tanto, hierve agua en una cazuela grande. Añade los fideos en el agua hirviendo y cocínalos durante unos minutos o según las instrucciones del paquete.<br />\nSirve la sopa bien caliente en bols individuales.<br />\nEscurre bien los fideos y sírvelos dentro de los boles con la sopa caliente.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1060', '<p>Pon la harina en un bol y añade la sal. Haz un hueco en el centro y agrega el agua y el aceite de oliva. </p>\n\n<p>Amasa todo bien hasta obtener una masa homogénea y compacta que no se pegue en las manos. Deja reposar la masa unos minutos.</p>\n\n<p>Divide la masa en 2 o 4 trozos (depende del tamaño de las pizzas que quieras preparar). </p>\n\n<p>Espolvorea con harina una superficie lisa y coloca encima una porción de masa. Estírala con ayuda del rodillo hasta que quede una masa fina (puedes dejarla más o menos fina, según el gusto).</p>\n\n<p>Coloca las masas, de una en una, sobre una bandeja de horno forrada con papel de horno.</p>\n\n<p>Añade los ingredientes que desees a las pizzas y hornéalas a 180ºC durante 15 minutos aproximadamente (con el horno precalentado).</p>\n\n<p>Es muy importante amasar bien la masa de pizza durante varios minutos, hasta que la masa no se pegue en los dedos.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1061', '<p>Cogemos un par de filetes de un grosor adecuado para que no nos queden demasiado secos al hacerlos a la plancha tras marinarlos, los lavamos bien bajo el grifo y los dejamos que escurran toda el agua. Mientras tanto vamos a coger un bol y en el mismo vamos a mezclar el aceite de oliva virgen, el vinagre, que puede ser del tipo que prefieras, y la mostaza de Dijon, junto a una pizca de sal, y vamos a mezclarlo bien hasta que se forme una crema más bien espesa. Ayúdate con unas varillas manuales para hacerlo más fácilmente. </p>\n\n<p>Con la marinada ya lista, embadurnamos bien los filetes de <strong>atún</strong>, los colocamos en una fuente dónde podamos colocarlos sin que se pisen, y echamos el resto de la marinada por encima. Con papel film vamos a cubrir bien la bandeja con el pescado y la marinada, y dejamos en la nevera que tomen el sabor durante una o dos horas al menos, así el atún irá absorbiendo los sabores de los ingredientes que hemos mezclado para marinarlos. </p>\n\n<p>Si lo vamos a tomar al natural, se puede añadir sesamo o salsa de soja.</p>\n\n<p>Si se va a cocinar el <strong>atún</strong>, vamos a necesitar una plancha o sartén, a la cual vamos a echar un chorrito de aceite de oliva virgen y ponemos a calentar a fuego intenso. </p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1062', '<p>Pon el <strong>horno</strong> a calentar (arriba y abajo) a 200ºC. Pasa las <strong>doradas</strong> bajo el grifo y deja que escurran todo el agua.</p>\n\n<p>Coge una bandeja de horno y coloca un papel de hornear. Coloca las doradas encima del papel. Si no tienes papel de hornear puedes hacer un lecho con la misma sal que usaremos para cubrir las doradas, pero si tienes la sal justa también puedes poner como última opción un chorrito de aceite de oliva bajo las doradas. Extiéndelo bien con un pincel para evitar que las doradas se peguen a la bandeja.</p>\n\n<p>Coge la sal y empieza a cubrir las doradas. Fíjate en la foto de la esquina que las dos doradas deben quedar totalmente cubiertas con la sal.</p>\n\n<p>Ahora calcula donde puede encontrarse <strong>el ojo de una de las doradas</strong> y escarba con el dedo en la sal hasta dejar el ojo libre. De esta forma podrás comprobar cuando la dorada está completamente hecha, aunque si no tienes práctica resulta un poco complicado cogerle el punto y es mejor seguir los tiempos de horneado.</p>\n\n<p>Mete la bandeja en el horno a 200ºC y deja que se hagan las doradas durante 35 minutos.<strong> </strong>Con un tenedor empieza a retirar hacia los lados la sal que cubre la dorada. Mete una espátula bajo la misma y sírvela en u plato. </p>\n\n<p><strong>Como acompañamiento de las doradas</strong> puedes poner unas “papas aliñas” (ensalada de patatas) sin atún, o una salsa alioli, unas verduritas al horno, o unas patatas panaderas, a tu gusto.</p>\n\n<p> </p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1064', '<p>Limpia el pescado de pieles y espinas y trocea junto con los langostinos. Reserva. Sofríe la cebolla bien picada e incorpora el pescado y los langostinos. Sazona y añade el caldo..</p>\n\n<p>Tuesta ligeramente la harina en un poco de aceite e incorpora el preparado anterior y una pizca de levadura. Añade la leche hasta formar una pasta compacta (que se desprenda de las paredes de la sartén).</p>\n\n<p>Retira del fuego y añade la yema de huevo. Deja enfriar y forma buñuelos pequeños con dos cucharillas. Pásalos por huevo y pan rallado y fríe en una sartén con aceite caliente. Sírvelos recién hechos, tal cual o ensartados en unas brochetas.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1063', '<p>Empezaremos preparando el condimento para el sushi. En una recipiente pequeño calentamos el vinagre con el azúcar y la sal y mezclamos hasta que se disuelva. No debe hervir, solo calentarlo un poco. Después lo dejamos enfriar. Hacemos los cuatro remojos al arroz. Lo dejaremos una hora escurrido.</p>\n\n<p>Ponemos el arroz en una olla y añadimos el agua. Dejamos reposar 10 minutos. Después lo ponemos sobre el fuego fuerte y cuando empiece a hervir lo tapamos, bajamos el fuego y dejamos 10 minutos más. Cuando termine apartamos, y sin destapar dejamos 15 minutos más.</p>\n\n<p>Usando las manos, formaremos 5 o 6 piezas ovaladas con el arroz.</p>\n\n<p>Cortaremos el salmón en filetes finos, ligeramente más grandes que las piezas de arroz.</p>\n\n<p>Colocaremos las lonchas de salmón sobre el arroz, recomiendo acompañar con salsa de soja, y wasabi.</p>\n\n<p>Tambien puedes colocar atún, pez blanco, o pulpo en el lugar del salmón.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1065', '<p>Corta el melón por la mitad y despepítalo. Ahora extráele la pulpa y tritúrala junto con el zumo de limón, el zumo de piña y el azúcar.</p>\n\n<p><br />\nMonta las claras de huevo a punto de nieve e incorpóraselas al triturado anterior.<br />\nIntroduce el preparado en el congelador durante 3 a 4 horas. Transcurrido este tiempo, bátelo con unas varillas y sírvelo bien frío.</p>\n\n<p>Adorna el sorbete con unas hojas de hierbabuena.</p>');
INSERT INTO `field_preparacion` (`pages_id`, `data`) VALUES('1066', '<p>Lava muy bien las espinacas y procede a cortarlas en algunas hojas finas. Corta también el perejil hasta que te quede bien picadito.</p>\n\n<p>En un bol rompe los dos huevos y añade sal y pimienta a las claras. Bátelas lentamente a mano hasta que se encuentren bien suavecitas. Añade las espinacas y el perejil en el bol y bate nuevamente, hasta formar una pasta de consistencia espesa.</p>\n\n<p>En una sartén pon la mantequilla y calientala hasta que quede derretida. Enseguida vas a verter la mezcla que prepararaste en el bol. Comienza a dorarla a fuego lento y cuídate de voltearla para que quede bien cocida de ambos lados. Doblalá sobre sí misma cuando se forme una especie de tortilla y tendrás listo tu omelette.</p>');

DROP TABLE IF EXISTS `field_process`;
CREATE TABLE `field_process` (
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `data` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_process` (`pages_id`, `data`) VALUES('6', '17');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('3', '12');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('8', '12');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('9', '14');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('10', '7');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('11', '47');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('16', '48');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('300', '104');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('21', '50');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('29', '66');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('23', '10');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('304', '138');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('31', '136');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('22', '76');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('30', '68');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('303', '129');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('2', '87');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('302', '121');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('301', '109');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('28', '76');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1007', '150');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1009', '158');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1011', '159');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1017', '163');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1019', '164');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1054', '175');

DROP TABLE IF EXISTS `field_roles`;
CREATE TABLE `field_roles` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_sidebar`;
CREATE TABLE `field_sidebar` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_sidebar` (`pages_id`, `data`) VALUES('1', '<h3>About ProcessWire</h3>\r\n\r\n<p>ProcessWire is an open source CMS and web application framework aimed at the needs of designers, developers and their clients.</p>\r\n\r\n<ul>\r\n	<li><a href=\"http://processwire.com/talk/\">Support</a>&nbsp;</li>\r\n	<li><a href=\"http://processwire.com/docs/\">Documentation</a></li>\r\n	<li><a href=\"http://processwire.com/docs/tutorials/\">Tutorials</a></li>\r\n	<li><a href=\"http://cheatsheet.processwire.com\">API Cheatsheet</a></li>\r\n	<li><a href=\"http://modules.processwire.com\">Modules/Plugins</a></li>\r\n</ul>');
INSERT INTO `field_sidebar` (`pages_id`, `data`) VALUES('1002', '<h3>Sudo nullus</h3>\r\n\r\n<p>Et torqueo vulpes vereor luctus augue quod consectetuer antehabeo causa patria tation ex plaga ut. Abluo delenit wisi iriure eros feugiat probo nisl aliquip nisl, patria. Antehabeo esse camur nisl modo utinam. Sudo nullus ventosus ibidem facilisis saepius eum sino pneum, vicis odio voco opto.</p>');

DROP TABLE IF EXISTS `field_summary`;
CREATE TABLE `field_summary` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1002', 'Dolore ea valde refero feugait utinam luctus. Probo velit commoveo et, delenit praesent, suscipit zelus, hendrerit zelus illum facilisi, regula. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1001', 'This is a placeholder page with two child pages to serve as an example. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1005', 'View this template\'s source for a demonstration of how to create a basic site map. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1004', 'Mos erat reprobo in praesent, mara premo, obruo iustum pecus velit lobortis te sagaciter populus.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1', 'ProcessWire is an open source CMS and web application framework aimed at the needs of designers, developers and their clients. ');

DROP TABLE IF EXISTS `field_tag1`;
CREATE TABLE `field_tag1` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1024', 'Marisco');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1025', 'Arroz');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1026', 'Bebida');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1027', 'Bebida');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1028', 'Fruta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1029', 'Bebida');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1030', 'Bebida');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1031', 'Dulces');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1032', 'Carnes');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1033', 'Carnes');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1034', 'Carnes');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1035', 'Carnes');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1036', 'Carnes');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1037', 'Carnes');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1038', 'Huevos');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1039', 'Huevos');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1040', 'Huevos');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1041', 'Arroz');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1042', 'Verdura');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1043', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1044', 'Verdura');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1046', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1047', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1045', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1048', 'Dulces');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1050', 'Fruta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1051', 'Dulces');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1052', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1053', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1055', 'Dulces');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1056', 'Arroz');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1057', 'Dulces');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1058', 'Bebida');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1059', 'Verdura');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1060', 'Pasta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1049', 'Dulces');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1061', 'Pescado');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1062', 'Pescado');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1063', 'Pescado');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1064', 'Marisco');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1065', 'Fruta');
INSERT INTO `field_tag1` (`pages_id`, `data`) VALUES('1066', 'Huevos');

DROP TABLE IF EXISTS `field_tag2`;
CREATE TABLE `field_tag2` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1024', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1025', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1026', 'Fruta');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1028', 'Bebida');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1064', 'Pescado');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1035', 'Huevos');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1063', 'Arroz');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1038', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1039', 'Pasta');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1040', 'Carnes');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1041', 'Carnes');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1042', 'Carnes');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1046', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1047', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1045', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1051', 'Fruta');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1052', 'Verdura');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1053', 'Carnes');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1056', 'Marisco');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1057', 'Fruta');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1059', 'Pasta');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1065', 'Dulces');
INSERT INTO `field_tag2` (`pages_id`, `data`) VALUES('1066', 'Verdura');

DROP TABLE IF EXISTS `field_tag3`;
CREATE TABLE `field_tag3` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1028', 'Dulces');
INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1065', 'Bebida');
INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1041', 'Verdura');
INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1047', 'Marisco');
INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1052', 'Carnes');
INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1056', 'Verdura');
INSERT INTO `field_tag3` (`pages_id`, `data`) VALUES('1059', 'Arroz');

DROP TABLE IF EXISTS `field_tag4`;
CREATE TABLE `field_tag4` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_tag4` (`pages_id`, `data`) VALUES('1059', 'Carnes');

DROP TABLE IF EXISTS `field_time`;
CREATE TABLE `field_time` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1024', '2');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1025', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1026', '1');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1027', '1');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1028', '1');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1029', '1');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1030', '4');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1031', '6');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1032', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1033', '6');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1034', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1035', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1036', '8');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1037', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1038', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1039', '6');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1040', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1041', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1042', '4');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1043', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1044', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1045', '6');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1046', '4');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1047', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1048', '4');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1049', '2');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1050', '8');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1051', '8');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1052', '8');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1053', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1055', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1056', '8');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1057', '8');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1058', '2');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1059', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1060', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1061', '9');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1062', '6');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1063', '7');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1064', '5');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1065', '10');
INSERT INTO `field_time` (`pages_id`, `data`) VALUES('1066', '2');

DROP TABLE IF EXISTS `field_title`;
CREATE TABLE `field_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_title` (`pages_id`, `data`) VALUES('11', 'Templates');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('16', 'Fields');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('22', 'Setup');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('3', 'Pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('6', 'Add Page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('8', 'Tree');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('9', 'Save Sort');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('10', 'Edit');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('21', 'Modules');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('29', 'Users');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('30', 'Roles');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('2', 'Admin');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('7', 'Trash');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('27', '404 Page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('302', 'Insert Link');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('23', 'Login');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('304', 'Profile');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('301', 'Empty Trash');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('300', 'Search');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('303', 'Insert Image');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('28', 'Access');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('31', 'Permissions');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('32', 'Edit pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('34', 'Delete pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('35', 'Move pages (change parent)');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('36', 'View pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('50', 'Sort child pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('51', 'Change templates on pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('52', 'Administer users');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('53', 'User can update profile/password');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('54', 'Lock or unlock a page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1', 'Home');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1001', 'About');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1002', 'Child page example 1');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1000', 'Search');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1004', 'Child page example 2');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1005', 'Site Map');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1006', 'Use Page Lister');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1007', 'Find');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1009', 'Recent');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1010', 'Can see recently edited pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1011', 'Logs');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1012', 'Can view system logs');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1013', 'Can manage system logs');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1014', 'Listado de recetas:');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1016', 'Administer languages and static translation files');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1017', 'Languages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1018', 'Default');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1019', 'Language Translator');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1020', 'es');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1021', 'Receta');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1022', 'Sobre mi');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1023', 'Sugerencias');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1024', 'Ensalada de surimi y camarones');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1025', 'Risotto cremoso de setas');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1026', 'Refresco de granada');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1027', 'Gin Tonic');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1028', 'Smoothie de banana');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1029', 'Granizado de café');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1030', 'Té helado con limón');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1031', 'Chocolate a la taza');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1032', 'Pechugas de pollo a la francesa');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1033', 'Solomillo de pavo asado');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1034', 'Solomillo al horno');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1035', 'Solomillo wellington');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1036', 'Pierna de cordero al horno con patatas panaderas');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1037', 'Pechugas asadas rellenas de manzana, pasas y nueces');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1038', 'Tortilla de patatas');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1039', 'Souffle de mozzarella y bacon');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1040', 'Huevos a la escocesa');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1041', 'Cuscús de cordero al estilo mozárabe');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1042', 'Ensalada de perdiz escabechada');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1043', 'Tortas de trigo');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1044', 'Sanfaina');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1045', 'Macarrones a la puttanesca');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1046', 'Ensalada caprese de pasta');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1047', 'Fideos chinos con gambas');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1048', 'Pastel bavarois');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1049', 'McFlurry casero');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1050', 'Cerezas al vino');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1051', 'Baklavas griegos');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1052', 'Moussaka');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1053', 'Calzone de queso, huevo y jamón');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1054', 'Image crop');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1055', 'brownie de chocolate');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1056', 'California roll');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1057', 'Helado de almendra');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1058', 'Lago azul');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1059', 'Ramen');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1060', 'Masa para pizzas');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1061', 'Atún marinado');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1062', 'Dorada a la sal');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1063', 'Nigiri de salmón');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1064', 'Buñuelos de langostinos');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1065', 'Sorbete de melón');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1066', 'Omelette de espinacas');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1067', 'pwangular');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1068', 'pwangular');

DROP TABLE IF EXISTS `fieldgroups`;
CREATE TABLE `fieldgroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

INSERT INTO `fieldgroups` (`id`, `name`) VALUES('2', 'admin');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('3', 'user');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('4', 'role');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('5', 'permission');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('1', 'home');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('88', 'sitemap');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('83', 'basic-page');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('80', 'search');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('97', 'language');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('98', 'receta');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('99', 'about');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('102', 'sugerencias');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('101', 'recetas');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('104', 'pwangular');

DROP TABLE IF EXISTS `fieldgroups_fields`;
CREATE TABLE `fieldgroups_fields` (
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fields_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`fieldgroups_id`,`fields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('2', '2', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('2', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '4', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '92', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('4', '5', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('5', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '100', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '44', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '76', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('80', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '44', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '76', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '78', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('88', '79', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '79', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '82', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('88', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '82', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '78', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '79', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '98', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '99', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '3', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '101', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '44', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '102', '3', '{\"columnWidth\":25}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '104', '4', '{\"columnWidth\":25,\"label\":\"Tipo\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '103', '5', '{\"columnWidth\":25}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '112', '6', '{\"columnWidth\":25,\"label\":\"Etiqueta 1\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '113', '7', '{\"columnWidth\":25}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '114', '8', '{\"columnWidth\":25}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '115', '9', '{\"columnWidth\":25}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '107', '10', '{\"columnWidth\":50}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '108', '11', '{\"columnWidth\":50}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '110', '2', '{\"columnWidth\":25}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('99', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '44', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('104', '1', '0', NULL);

DROP TABLE IF EXISTS `fields`;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET ascii NOT NULL,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('1', 'FieldtypePageTitle', 'title', '13', 'Título', '{\"required\":1,\"textformatters\":[\"TextformatterEntities\"],\"size\":0,\"maxlength\":255,\"collapsed\":0,\"icon\":\"circle\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('2', 'FieldtypeModule', 'process', '25', 'Process', '{\"description\":\"The process that is executed on this page. Since this is mostly used by ProcessWire internally, it is recommended that you don\'t change the value of this unless adding your own pages in the admin.\",\"collapsed\":1,\"required\":1,\"moduleTypes\":[\"Process\"],\"permanent\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('3', 'FieldtypePassword', 'pass', '24', 'Set Password', '{\"collapsed\":1,\"size\":50,\"maxlength\":128}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('5', 'FieldtypePage', 'permissions', '24', 'Permissions', '{\"derefAsPage\":0,\"parent_id\":31,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldCheckboxes\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('4', 'FieldtypePage', 'roles', '24', 'Roles', '{\"derefAsPage\":0,\"parent_id\":30,\"labelFieldName\":\"name\",\"inputfield\":\"InputfieldCheckboxes\",\"description\":\"User will inherit the permissions assigned to each role. You may assign multiple roles to a user. When accessing a page, the user will only inherit permissions from the roles that are also assigned to the page\'s template.\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('92', 'FieldtypeEmail', 'email', '9', 'E-Mail Address', '{\"size\":70,\"maxlength\":255}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('82', 'FieldtypeTextarea', 'sidebar', '0', 'Sidebar', '{\"inputfieldClass\":\"InputfieldCKEditor\",\"rows\":5,\"contentType\":1,\"toolbar\":\"Format, Bold, Italic, -, RemoveFormat\\r\\nNumberedList, BulletedList, -, Blockquote\\r\\nPWLink, Unlink, Anchor\\r\\nPWImage, Table, HorizontalRule, SpecialChar\\r\\nPasteText, PasteFromWord\\r\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[2,4,8],\"collapsed\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('44', 'FieldtypeCropImage', 'images', '0', 'Imagen', '{\"extensions\":\"gif jpg jpeg png\",\"adminThumbs\":1,\"inputfieldClass\":\"InputfieldCropImage\",\"maxFiles\":0,\"descriptionRows\":1,\"fileSchema\":2,\"textformatters\":[\"TextformatterEntities\"],\"outputFormat\":1,\"defaultValuePage\":0,\"defaultGrid\":0,\"icon\":\"camera\",\"maxReject\":0,\"collapsed\":0,\"thumbSetting\":\"thumbnail,375,250\\nportrait,750,500\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('79', 'FieldtypeTextarea', 'summary', '1', 'Summary', '{\"textformatters\":[\"TextformatterEntities\"],\"inputfieldClass\":\"InputfieldTextarea\",\"collapsed\":2,\"rows\":3,\"contentType\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('76', 'FieldtypeTextarea', 'body', '0', 'Body', '{\"inputfieldClass\":\"InputfieldCKEditor\",\"rows\":10,\"contentType\":1,\"toolbar\":\"Format, Bold, Italic, -, RemoveFormat\\r\\nNumberedList, BulletedList, -, Blockquote\\r\\nPWLink, Unlink, Anchor\\r\\nPWImage, Table, HorizontalRule, SpecialChar\\r\\nPasteText, PasteFromWord\\r\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[2,4,8]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('78', 'FieldtypeText', 'headline', '0', 'Headline', '{\"description\":\"Use this instead of the Title if a longer headline is needed than what you want to appear in navigation.\",\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":2,\"size\":0,\"maxlength\":1024}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('98', 'FieldtypeFile', 'language_files_site', '24', 'Site Translation Files', '{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for translations specific to your site (like files in \\/site\\/templates\\/ for example).\",\"descriptionRows\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('99', 'FieldtypeFile', 'language_files', '24', 'Core Translation Files', '{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for [language packs](http:\\/\\/modules.processwire.com\\/categories\\/language-pack\\/). To delete all files, double-click the trash can for any file, then save.\",\"descriptionRows\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('100', 'FieldtypePage', 'language', '24', 'Language', '{\"derefAsPage\":1,\"parent_id\":1017,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldRadios\",\"required\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('101', 'FieldtypeModule', 'admin_theme', '8', 'Admin Theme', '{\"moduleTypes\":[\"AdminTheme\"],\"labelField\":\"title\",\"inputfieldClass\":\"InputfieldRadios\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('102', 'FieldtypeSelect', 'dificultad', '0', 'Dificultad', '{\"select_options\":\"1:=F\\u00e1cil\\n2:=Media\\n3:=Dif\\u00edcil\",\"collapsed\":0,\"icon\":\"reorder\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('103', 'FieldtypeSelect', 'personas', '0', 'Personas', '{\"select_options\":\"1:=1 persona\\n2:=2 personas\\n3:=3 personas\\n4:=4 personas\",\"collapsed\":0,\"icon\":\"users\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('104', 'FieldtypeSelect', 'category', '0', 'Categoría', '{\"select_options\":\"Aperitivo\\nPlato\\nBebida\\nPostre\",\"collapsed\":0,\"icon\":\"spoon\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('115', 'FieldtypeSelect', 'tag4', '0', 'Etiqueta 4', '{\"select_options\":\"Verdura\\nCarnes\\nPescado\\nMarisco\\nHuevos\\nPasta\\nArroz\\nBebida\\nFruta\\nDulces\",\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('107', 'FieldtypeTextarea', 'ingredientes', '0', 'Ingredientes', '{\"inputfieldClass\":\"InputfieldCKEditor\",\"contentType\":0,\"collapsed\":0,\"rows\":5,\"toolbar\":\"Format, Styles, -, Bold, Italic, -, RemoveFormat\\nNumberedList, BulletedList, -, Blockquote\\nPWLink, Unlink, Anchor\\nPWImage, Table, HorizontalRule, SpecialChar\\nPasteText, PasteFromWord\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h1;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('108', 'FieldtypeTextarea', 'preparacion', '0', 'Preparación', '{\"inputfieldClass\":\"InputfieldCKEditor\",\"contentType\":0,\"collapsed\":0,\"rows\":5,\"toolbar\":\"Format, Styles, -, Bold, Italic, -, RemoveFormat\\nNumberedList, BulletedList, -, Blockquote\\nPWLink, Unlink, Anchor\\nPWImage, Table, HorizontalRule, SpecialChar\\nPasteText, PasteFromWord\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h1;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('110', 'FieldtypeSelect', 'time', '0', 'Tiempo', '{\"select_options\":\"1:=5 minutos\\n2:=10 minutos\\n3:=15 minutos\\n4:=20 minutos\\n5:=30 minutos\\n6:=45 minutos\\n7:=1 hora\\n8:=1 hora y media\\n9:=2 horas\\n10:=3 horas\",\"collapsed\":0,\"icon\":\"clock-o\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('111', 'FieldtypeCropImage', 'crop', '0', '', '{\"fileSchema\":2,\"extensions\":\"gif jpg jpeg png\",\"maxFiles\":0,\"outputFormat\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldCropImage\",\"collapsed\":0,\"descriptionRows\":1,\"defaultGrid\":0,\"maxReject\":0,\"thumbSetting\":\"thumbnail,250,250\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('112', 'FieldtypeSelect', 'tag1', '0', 'Etiqueta1', '{\"select_options\":\"Verdura\\nCarnes\\nPescado\\nMarisco\\nHuevos\\nPasta\\nArroz\\nBebida\\nFruta\\nDulces\",\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('113', 'FieldtypeSelect', 'tag2', '0', 'Etiqueta 2', '{\"select_options\":\"Verdura\\nCarnes\\nPescado\\nMarisco\\nHuevos\\nPasta\\nArroz\\nBebida\\nFruta\\nDulces\",\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('114', 'FieldtypeSelect', 'tag3', '0', 'Etiqueta 3', '{\"select_options\":\"Verdura\\nCarnes\\nPescado\\nMarisco\\nHuevos\\nPasta\\nArroz\\nBebida\\nFruta\\nDulces\",\"collapsed\":0}');

DROP TABLE IF EXISTS `fieldtype_options`;
CREATE TABLE `fieldtype_options` (
  `fields_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `title` text,
  `value` varchar(255) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fields_id`,`option_id`),
  UNIQUE KEY `title` (`title`(255),`fields_id`),
  KEY `value` (`value`,`fields_id`),
  KEY `sort` (`sort`,`fields_id`),
  FULLTEXT KEY `title_value` (`title`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '1', 'Verdura', '', '0');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '2', 'Carnes', '', '1');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '3', 'Pescado', '', '2');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '4', 'Marisco', '', '3');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '5', 'Huevos', '', '4');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '6', 'Pasta', '', '5');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '7', 'Arroz', '', '6');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '8', 'Bebida', '', '7');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '9', 'Fruta', '', '8');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('106', '10', 'Dulces', '', '9');

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM AUTO_INCREMENT=180 DEFAULT CHARSET=utf8;

INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('1', 'FieldtypeTextarea', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('2', 'FieldtypeNumber', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('3', 'FieldtypeText', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('4', 'FieldtypePage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('30', 'InputfieldForm', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('6', 'FieldtypeFile', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('7', 'ProcessPageEdit', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('10', 'ProcessLogin', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('12', 'ProcessPageList', '0', '{\"pageLabelField\":\"title\",\"paginationLimit\":25,\"limit\":50}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('121', 'ProcessPageEditLink', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('14', 'ProcessPageSort', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('15', 'InputfieldPageListSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('117', 'JqueryUI', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('17', 'ProcessPageAdd', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('125', 'SessionLoginThrottle', '11', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('122', 'InputfieldPassword', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('25', 'InputfieldAsmSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('116', 'JqueryCore', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('27', 'FieldtypeModule', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('28', 'FieldtypeDatetime', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('29', 'FieldtypeEmail', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('108', 'InputfieldURL', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('32', 'InputfieldSubmit', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('33', 'InputfieldWrapper', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('34', 'InputfieldText', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('35', 'InputfieldTextarea', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('36', 'InputfieldSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('37', 'InputfieldCheckbox', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('38', 'InputfieldCheckboxes', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('39', 'InputfieldRadios', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('40', 'InputfieldHidden', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('41', 'InputfieldName', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('43', 'InputfieldSelectMultiple', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('45', 'JqueryWireTabs', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('46', 'ProcessPage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('47', 'ProcessTemplate', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('48', 'ProcessField', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('50', 'ProcessModule', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('114', 'PagePermissions', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('97', 'FieldtypeCheckbox', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('115', 'PageRender', '3', '{\"clearCache\":1}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('55', 'InputfieldFile', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('56', 'InputfieldImage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('57', 'FieldtypeImage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('60', 'InputfieldPage', '0', '{\"inputfieldClasses\":[\"InputfieldSelect\",\"InputfieldSelectMultiple\",\"InputfieldCheckboxes\",\"InputfieldRadios\",\"InputfieldAsmSelect\",\"InputfieldPageListSelect\",\"InputfieldPageListSelectMultiple\",\"InputfieldPageAutocomplete\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('61', 'TextformatterEntities', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('66', 'ProcessUser', '0', '{\"showFields\":[\"name\",\"email\",\"roles\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('67', 'MarkupAdminDataTable', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('68', 'ProcessRole', '0', '{\"showFields\":[\"name\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('76', 'ProcessList', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('78', 'InputfieldFieldset', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('79', 'InputfieldMarkup', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('80', 'InputfieldEmail', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('89', 'FieldtypeFloat', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('83', 'ProcessPageView', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('84', 'FieldtypeInteger', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('85', 'InputfieldInteger', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('86', 'InputfieldPageName', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('87', 'ProcessHome', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('90', 'InputfieldFloat', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('94', 'InputfieldDatetime', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('98', 'MarkupPagerNav', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('129', 'ProcessPageEditImageSelect', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('103', 'JqueryTableSorter', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('104', 'ProcessPageSearch', '1', '{\"searchFields\":\"title\",\"displayField\":\"title path\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('105', 'FieldtypeFieldsetOpen', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('106', 'FieldtypeFieldsetClose', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('107', 'FieldtypeFieldsetTabOpen', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('109', 'ProcessPageTrash', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('111', 'FieldtypePageTitle', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('112', 'InputfieldPageTitle', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('113', 'MarkupPageArray', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('131', 'InputfieldButton', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('133', 'FieldtypePassword', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('134', 'ProcessPageType', '1', '{\"showFields\":[]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('135', 'FieldtypeURL', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('136', 'ProcessPermission', '1', '{\"showFields\":[\"name\",\"title\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('137', 'InputfieldPageListSelectMultiple', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('138', 'ProcessProfile', '1', '{\"profileFields\":[\"pass\",\"email\",\"language\",\"admin_theme\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('139', 'SystemUpdater', '1', '{\"systemVersion\":14,\"coreVersion\":\"2.7.2\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('148', 'AdminThemeDefault', '10', '{\"colors\":\"classic\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('149', 'InputfieldSelector', '10', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('150', 'ProcessPageLister', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('151', 'JqueryMagnific', '1', '', '2014-07-21 07:21:45');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('152', 'PagePathHistory', '3', '', '2014-07-25 09:36:57');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('155', 'InputfieldCKEditor', '0', '', '2014-07-25 10:26:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('156', 'MarkupHTMLPurifier', '0', '', '2014-07-25 10:26:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('158', 'ProcessRecentPages', '1', '', '2016-02-24 16:22:36');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('159', 'ProcessLogger', '1', '', '2016-02-24 16:23:20');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('160', 'InputfieldIcon', '0', '', '2016-02-24 16:23:20');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('162', 'LanguageSupport', '3', '{\"languagesPageID\":1017,\"defaultLanguagePageID\":1018,\"otherLanguagePageIDs\":[1020],\"languageTranslatorPageID\":1019}', '2016-02-24 17:24:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('163', 'ProcessLanguage', '1', '', '2016-02-24 17:24:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('164', 'ProcessLanguageTranslator', '1', '', '2016-02-24 17:24:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('165', 'AdminThemeReno', '10', '{\"colors\":\"blue\",\"avatar_field_user\":\"\",\"userFields_user\":\"name\",\"notices\":\"fa-bell\",\"home\":\"fa-home\",\"signout\":\"fa-power-off\",\"page\":\"fa-file-text\",\"setup\":\"fa-wrench\",\"module\":\"fa-briefcase\",\"access\":\"fa-unlock\"}', '2016-02-24 17:52:58');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('166', 'FieldtypeMapMarker', '1', '', '2016-02-25 15:24:32');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('167', 'InputfieldMapMarker', '0', '', '2016-02-25 15:24:32');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('168', 'FieldtypeSelect', '1', '', '2016-02-25 15:24:53');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('169', 'Pages2JSON', '3', '', '2016-02-25 15:25:08');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('172', 'FieldtypeModules', '1', '', '2016-02-25 15:54:41');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('174', 'InputfieldPageAutocomplete', '0', '', '2016-02-29 16:37:10');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('173', 'FieldtypeOptions', '1', '', '2016-02-25 15:58:15');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('175', 'ProcessCropImage', '1', '', '2016-03-02 18:50:54');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('176', 'FieldtypeCropImage', '1', '', '2016-03-02 18:50:54');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('177', 'InputfieldCropImage', '0', '', '2016-03-02 18:50:54');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('178', 'Pwapi', '3', '', '2016-03-10 18:12:57');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('179', 'WireMailSmtp', '0', '{\"localhost\":\"primagen.bitnamiapp.com\",\"smtp_host\":\"smtp.gmail.com\",\"smtp_port\":587,\"smtp_start_tls\":1,\"smtp_ssl\":\"\",\"smtp_user\":\"albertomrobert@gmail.com\",\"smtp_password\":\"wrwuulftsnuuqcqp\",\"smtp_certificate\":\"\",\"authentication_mechanism\":\"\",\"realm\":\"\",\"workstation\":\"\",\"sender_email\":\"albertomrobert@gmail.com\",\"sender_name\":\"Gracias por tu sugerencia.\",\"sender_reply\":\"\",\"sender_errors_to\":\"\",\"sender_signature\":\"\",\"sender_signature_html\":\"\",\"send_sender_signature\":\"1\",\"valid_recipients\":\"\",\"extra_headers\":\"\"}', '2016-03-10 18:13:30');

DROP TABLE IF EXISTS `page_path_history`;
CREATE TABLE `page_path_history` (
  `path` varchar(255) NOT NULL,
  `pages_id` int(10) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`path`),
  KEY `pages_id` (`pages_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `templates_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET ascii NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `published` datetime DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_parent_id` (`name`,`parent_id`),
  KEY `parent_id` (`parent_id`),
  KEY `templates_id` (`templates_id`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `status` (`status`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=1069 DEFAULT CHARSET=utf8;

INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1', '0', '1', 'home', '9', '2016-02-25 18:05:18', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('2', '1', '2', 'admin', '1035', '2016-02-24 16:22:37', '40', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('3', '2', '2', 'page', '21', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('6', '3', '2', 'add', '21', '2016-02-24 16:23:30', '40', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('7', '1', '2', 'trash', '1039', '2011-08-14 22:04:52', '41', '2010-02-07 05:29:39', '2', '2010-02-07 05:29:39', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('8', '3', '2', 'list', '1045', '2016-02-24 16:23:30', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('9', '3', '2', 'sort', '1047', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('10', '3', '2', 'edit', '1045', '2016-02-24 16:23:30', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('11', '22', '2', 'template', '21', '2011-03-29 21:37:06', '41', '2010-02-01 11:04:54', '2', '2010-02-01 11:04:54', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('16', '22', '2', 'field', '21', '2011-03-29 21:37:06', '41', '2010-02-01 12:44:07', '2', '2010-02-01 12:44:07', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('21', '2', '2', 'module', '21', '2011-03-29 21:37:06', '41', '2010-02-02 10:02:24', '2', '2010-02-02 10:02:24', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('22', '2', '2', 'setup', '21', '2011-03-29 21:37:06', '41', '2010-02-09 12:16:59', '2', '2010-02-09 12:16:59', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('23', '2', '2', 'login', '1035', '2011-05-03 23:38:10', '41', '2010-02-17 09:59:39', '2', '2010-02-17 09:59:39', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('27', '1', '29', 'http404', '1035', '2014-07-25 07:34:57', '41', '2010-06-03 06:53:03', '3', '2010-06-03 06:53:03', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('28', '2', '2', 'access', '13', '2011-05-03 23:38:10', '41', '2011-03-19 19:14:20', '2', '2011-03-19 19:14:20', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('29', '28', '2', 'users', '29', '2011-04-05 00:39:08', '41', '2011-03-19 19:15:29', '2', '2011-03-19 19:15:29', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('30', '28', '2', 'roles', '29', '2011-04-05 00:38:39', '41', '2011-03-19 19:15:45', '2', '2011-03-19 19:15:45', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('31', '28', '2', 'permissions', '29', '2011-04-05 00:53:52', '41', '2011-03-19 19:16:00', '2', '2011-03-19 19:16:00', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('32', '31', '5', 'page-edit', '25', '2011-09-06 15:34:24', '41', '2011-03-19 19:17:03', '2', '2011-03-19 19:17:03', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('34', '31', '5', 'page-delete', '25', '2011-09-06 15:34:33', '41', '2011-03-19 19:17:23', '2', '2011-03-19 19:17:23', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('35', '31', '5', 'page-move', '25', '2011-09-06 15:34:48', '41', '2011-03-19 19:17:41', '2', '2011-03-19 19:17:41', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('36', '31', '5', 'page-view', '25', '2011-09-06 15:34:14', '41', '2011-03-19 19:17:57', '2', '2011-03-19 19:17:57', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('37', '30', '4', 'guest', '25', '2011-04-05 01:37:19', '41', '2011-03-19 19:18:41', '2', '2011-03-19 19:18:41', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('38', '30', '4', 'superuser', '25', '2011-08-17 14:34:39', '41', '2011-03-19 19:18:55', '2', '2011-03-19 19:18:55', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('41', '29', '3', 'admin', '1', '2016-02-24 17:58:12', '41', '2011-03-19 19:41:26', '2', '2011-03-19 19:41:26', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('40', '29', '3', 'guest', '25', '2016-02-24 17:51:38', '41', '2011-03-20 17:31:59', '2', '2011-03-20 17:31:59', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('50', '31', '5', 'page-sort', '25', '2011-09-06 15:34:58', '41', '2011-03-26 22:04:50', '41', '2011-03-26 22:04:50', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('51', '31', '5', 'page-template', '25', '2011-09-06 15:35:09', '41', '2011-03-26 22:25:31', '41', '2011-03-26 22:25:31', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('52', '31', '5', 'user-admin', '25', '2011-09-06 15:35:42', '41', '2011-03-30 00:06:47', '41', '2011-03-30 00:06:47', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('53', '31', '5', 'profile-edit', '1', '2011-08-16 22:32:48', '41', '2011-04-26 00:02:22', '41', '2011-04-26 00:02:22', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('54', '31', '5', 'page-lock', '1', '2011-08-15 17:48:12', '41', '2011-08-15 17:45:48', '41', '2011-08-15 17:45:48', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('300', '3', '2', 'search', '1045', '2011-03-29 21:37:06', '41', '2010-08-04 05:23:59', '2', '2010-08-04 05:23:59', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('301', '3', '2', 'trash', '1047', '2011-03-29 21:37:06', '41', '2010-09-28 05:39:30', '2', '2010-09-28 05:39:30', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('302', '3', '2', 'link', '1041', '2011-03-29 21:37:06', '41', '2010-10-01 05:03:56', '2', '2010-10-01 05:03:56', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('303', '3', '2', 'image', '1041', '2011-03-29 21:37:06', '41', '2010-10-13 03:56:48', '2', '2010-10-13 03:56:48', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('304', '2', '2', 'profile', '1025', '2011-05-03 23:38:10', '41', '2011-04-25 23:57:18', '41', '2011-04-25 23:57:18', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1000', '1', '26', 'search', '1025', '2011-08-31 19:17:38', '41', '2010-09-06 05:05:28', '2', '2010-09-06 05:05:28', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1001', '7', '29', '1001.1.0_about', '8193', '2016-02-25 15:22:10', '41', '2010-10-25 22:39:33', '2', '2010-10-25 22:39:33', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1002', '1001', '29', 'what', '8193', '2014-07-25 15:31:43', '41', '2010-10-25 23:21:34', '2', '2010-10-25 23:21:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1004', '1001', '29', 'background', '8193', '2014-07-25 07:25:35', '41', '2010-11-29 22:11:36', '2', '2010-11-29 22:11:36', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1005', '7', '34', '1005.1.2_site-map', '8193', '2016-02-25 15:22:16', '41', '2010-11-30 21:16:49', '2', '2010-11-30 21:16:49', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1006', '31', '5', 'page-lister', '1', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1007', '3', '2', 'lister', '1', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1009', '3', '2', 'recent-pages', '1', '2016-02-24 16:22:36', '40', '2016-02-24 16:22:36', '40', '2016-02-24 16:22:36', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1010', '31', '5', 'page-edit-recent', '1', '2016-02-24 16:22:36', '40', '2016-02-24 16:22:36', '40', '2016-02-24 16:22:36', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1011', '22', '2', 'logs', '1', '2016-02-24 16:23:20', '40', '2016-02-24 16:23:20', '40', '2016-02-24 16:23:20', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1012', '31', '5', 'logs-view', '1', '2016-02-24 16:23:20', '40', '2016-02-24 16:23:20', '40', '2016-02-24 16:23:20', '11');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1013', '31', '5', 'logs-edit', '1', '2016-02-24 16:23:20', '40', '2016-02-24 16:23:20', '40', '2016-02-24 16:23:20', '12');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1014', '1', '47', 'recetas', '1', '2016-03-30 00:55:42', '41', '2016-02-24 16:25:24', '41', '2016-02-24 18:00:42', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1016', '31', '5', 'lang-edit', '1', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1017', '22', '2', 'languages', '16', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1018', '1017', '43', 'default', '16', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1019', '22', '2', 'language-translator', '1040', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '41', '2016-02-24 17:24:17', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1020', '1017', '43', 'es', '1', '2016-02-24 17:45:59', '41', '2016-02-24 17:43:32', '41', '2016-02-24 17:43:32', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1021', '7', '44', '1021.1.4_receta', '8193', '2016-02-25 18:06:07', '41', '2016-02-25 16:25:50', '41', '2016-02-25 16:26:00', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1022', '1', '45', 'about', '1', '2016-03-30 01:09:22', '41', '2016-02-25 17:43:48', '41', '2016-02-25 17:44:06', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1023', '1', '48', 'sugerencias', '1', '2016-03-14 16:24:32', '41', '2016-02-25 17:47:54', '41', '2016-02-25 17:47:57', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1024', '1014', '44', 'ensalada-de-surimi-y-camarones', '1', '2016-03-22 03:08:32', '41', '2016-02-25 18:06:24', '41', '2016-02-25 18:06:26', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1025', '1014', '44', 'risotto-cremoso-de-setas', '1', '2016-03-22 03:12:21', '41', '2016-02-25 18:18:27', '41', '2016-02-25 18:20:14', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1026', '1014', '44', 'refresco-de-granada', '1', '2016-03-30 00:55:42', '41', '2016-02-25 18:27:32', '41', '2016-02-25 18:29:01', '36');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1027', '1014', '44', 'gin-tonic', '1', '2016-03-22 03:08:46', '41', '2016-02-25 18:29:21', '41', '2016-02-25 18:30:24', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1028', '1014', '44', 'smoothie-de-banana', '1', '2016-03-22 03:13:58', '41', '2016-02-25 18:33:07', '41', '2016-02-25 18:34:22', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1029', '1014', '44', 'granizado-de-cafe', '1', '2016-03-22 03:14:04', '41', '2016-02-25 18:34:50', '41', '2016-02-25 18:35:58', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1030', '1014', '44', 'te-helado-con-limon', '1', '2016-03-22 03:10:29', '41', '2016-02-25 18:40:04', '41', '2016-02-25 18:41:01', '17');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1031', '1014', '44', 'chocolate-a-la-taza', '1', '2016-03-21 19:44:37', '41', '2016-02-25 18:41:30', '41', '2016-02-25 18:42:57', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1032', '1014', '44', 'pechugas-de-pollo-a-la-francesa', '1', '2016-03-22 01:40:57', '41', '2016-02-25 18:44:40', '41', '2016-02-25 19:03:06', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1033', '1014', '44', 'solomillo-de-pavo-asado', '1', '2016-03-30 00:17:14', '41', '2016-02-25 19:03:45', '41', '2016-02-25 19:06:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1034', '1014', '44', 'solomillo-al-horno', '1', '2016-03-22 01:48:30', '41', '2016-02-25 19:34:02', '41', '2016-02-25 19:35:25', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1035', '1014', '44', 'solomillo-con-hojaldre', '1', '2016-03-30 00:19:49', '41', '2016-02-25 19:36:26', '41', '2016-02-25 19:38:14', '18');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1036', '1014', '44', 'pierna-de-cordero-al-horno-con-patatas-panaderas', '1', '2016-03-22 03:13:10', '41', '2016-02-25 19:38:59', '41', '2016-02-25 19:40:18', '20');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1037', '1014', '44', 'pechugas-asadas-rellenas-de-manzana-pasas-y-nueces', '1', '2016-03-29 17:26:35', '41', '2016-02-25 19:40:56', '41', '2016-02-25 19:42:37', '12');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1038', '1014', '44', 'tortilla-de-patatas', '1', '2016-03-22 03:11:47', '41', '2016-02-29 15:54:14', '41', '2016-02-29 15:55:36', '15');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1039', '1014', '44', 'souffle-de-mozzarella-y-bacon', '1', '2016-03-30 00:21:50', '41', '2016-02-29 16:03:41', '41', '2016-02-29 16:05:22', '28');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1040', '1014', '44', 'huevos-a-la-escocesa', '1', '2016-03-30 00:24:28', '41', '2016-02-29 16:06:16', '41', '2016-02-29 16:07:08', '32');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1041', '1014', '44', 'cuscus-de-cordero-al-estilo-mozarabe', '1', '2016-03-22 03:09:33', '41', '2016-02-29 16:10:20', '41', '2016-02-29 16:11:52', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1042', '1014', '44', 'ensalada-de-perdiz-escabechada', '1', '2016-03-22 02:07:29', '41', '2016-02-29 16:13:38', '41', '2016-02-29 16:15:26', '19');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1043', '1014', '44', 'tortas-de-trigo', '1', '2016-03-22 02:08:15', '41', '2016-02-29 16:17:32', '41', '2016-02-29 16:19:24', '22');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1044', '1014', '44', 'sanfaina', '1', '2016-03-22 02:16:00', '41', '2016-02-29 16:21:11', '41', '2016-02-29 16:22:11', '23');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1045', '1014', '44', 'macarrones-a-la-puttanesca', '1', '2016-03-29 21:41:28', '41', '2016-02-29 16:25:31', '41', '2016-02-29 16:27:04', '27');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1046', '1014', '44', 'ensalada-caprese-de-pasta', '1', '2016-03-30 00:54:49', '41', '2016-02-29 16:28:07', '41', '2016-02-29 16:29:03', '40');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1047', '1014', '44', 'fideos-chinos-con-gambas', '1', '2016-03-22 02:17:10', '41', '2016-02-29 16:29:51', '41', '2016-02-29 16:30:47', '25');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1048', '1014', '44', 'pastel-bavarois', '1', '2016-03-22 02:18:02', '41', '2016-02-29 16:32:08', '41', '2016-02-29 16:33:54', '26');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1049', '1014', '44', 'mcflurry-casero', '1', '2016-03-29 17:57:29', '41', '2016-02-29 16:36:21', '41', '2016-02-29 16:38:24', '21');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1050', '1014', '44', 'cerezas-al-vino', '1', '2016-03-22 02:23:23', '41', '2016-02-29 16:40:08', '41', '2016-02-29 16:41:08', '29');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1051', '1014', '44', 'baklavas-griegos', '1', '2016-03-22 02:24:57', '41', '2016-03-01 16:07:14', '41', '2016-03-01 16:10:07', '30');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1052', '1014', '44', 'moussaka', '1', '2016-03-22 03:12:56', '41', '2016-03-01 16:12:38', '41', '2016-03-01 16:14:30', '11');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1053', '1014', '44', 'calzone-de-queso-huevo-y-jamon', '1', '2016-03-30 00:20:30', '41', '2016-03-01 16:16:36', '41', '2016-03-01 16:18:12', '31');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1054', '3', '2', 'image-crop', '1', '2016-03-02 18:50:54', '41', '2016-03-02 18:50:54', '41', '2016-03-02 18:50:54', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1055', '1014', '44', 'brownie-de-chocolate', '1', '2016-03-22 03:15:15', '41', '2016-03-13 22:30:04', '41', '2016-03-13 22:35:10', '35');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1056', '1014', '44', 'california-roll', '1', '2016-03-29 18:42:02', '41', '2016-03-13 22:39:53', '41', '2016-03-13 22:45:09', '24');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1057', '1014', '44', 'helado-de-almendra', '1', '2016-03-22 03:16:18', '41', '2016-03-22 02:34:08', '41', '2016-03-22 02:37:55', '14');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1058', '1014', '44', 'lago-azul', '1', '2016-03-22 03:14:43', '41', '2016-03-22 02:44:34', '41', '2016-03-22 02:49:02', '33');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1059', '1014', '44', 'ramen', '1', '2016-03-22 02:53:20', '41', '2016-03-22 02:50:37', '41', '2016-03-22 02:53:20', '37');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1060', '1014', '44', 'masa-para-pizzas', '1', '2016-03-29 21:41:20', '41', '2016-03-22 03:02:29', '41', '2016-03-22 03:08:03', '34');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1061', '1014', '44', 'atun-marinado', '1', '2016-03-29 21:41:14', '41', '2016-03-29 18:16:11', '41', '2016-03-29 18:20:35', '16');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1062', '1014', '44', 'dorada-a-la-sal', '1', '2016-03-30 00:17:35', '41', '2016-03-29 18:26:38', '41', '2016-03-29 18:30:30', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1063', '1014', '44', 'nigiri-de-salmon', '1', '2016-03-29 21:40:52', '41', '2016-03-29 18:36:05', '41', '2016-03-29 18:39:24', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1064', '1014', '44', 'bunuelos-de-langostinos', '1', '2016-03-30 00:30:15', '41', '2016-03-30 00:25:05', '41', '2016-03-30 00:30:15', '39');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1065', '1014', '44', 'sorbete-de-melon', '1', '2016-03-30 00:38:30', '41', '2016-03-30 00:35:58', '41', '2016-03-30 00:37:54', '41');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1066', '1014', '44', 'omelet-de-espinacas', '1', '2016-03-30 00:54:42', '41', '2016-03-30 00:49:50', '41', '2016-03-30 00:52:33', '38');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1067', '7', '1', '1067.1.7_pwangular', '8193', '2016-03-30 16:48:33', '41', '2016-03-30 15:56:41', '41', '2016-03-30 15:57:14', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1068', '1', '50', 'pwangular', '1', '2016-03-30 16:52:13', '41', '2016-03-30 16:52:07', '41', '2016-03-30 16:52:13', '7');

DROP TABLE IF EXISTS `pages_access`;
CREATE TABLE `pages_access` (
  `pages_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pages_id`),
  KEY `templates_id` (`templates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1018', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1020', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('37', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('38', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('32', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('34', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('35', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('36', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('50', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('51', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('52', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('53', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('54', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1006', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1010', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1012', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1013', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1016', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1002', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1004', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1001', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1005', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1021', '2', '2016-02-29 18:28:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1023', '1', '2016-03-14 16:24:32');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1056', '1', '2016-03-13 22:39:53');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1055', '1', '2016-03-13 22:30:04');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1014', '1', '2016-03-02 15:34:28');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1057', '1', '2016-03-22 02:34:08');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1058', '1', '2016-03-22 02:44:34');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1059', '1', '2016-03-22 02:50:37');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1060', '1', '2016-03-22 03:02:29');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1061', '1', '2016-03-29 18:16:11');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1062', '1', '2016-03-29 18:26:38');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1063', '1', '2016-03-29 18:36:05');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1064', '1', '2016-03-30 00:25:05');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1065', '1', '2016-03-30 00:35:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1066', '1', '2016-03-30 00:49:50');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1022', '1', '2016-03-30 01:09:22');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1068', '1', '2016-03-30 16:52:07');

DROP TABLE IF EXISTS `pages_parents`;
CREATE TABLE `pages_parents` (
  `pages_id` int(10) unsigned NOT NULL,
  `parents_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`parents_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('2', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('3', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('3', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('7', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('22', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('22', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('28', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('28', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1001', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1001', '7');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1002', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1002', '1001');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1004', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1004', '1001');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1005', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1014', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1017', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1017', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1017', '22');

DROP TABLE IF EXISTS `pages_sortfields`;
CREATE TABLE `pages_sortfields` (
  `pages_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sortfield` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `session_login_throttle`;
CREATE TABLE `session_login_throttle` (
  `name` varchar(128) NOT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_attempt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  `cache_time` mediumint(9) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fieldgroups_id` (`fieldgroups_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('2', 'admin', '2', '8', '0', '{\"useRoles\":1,\"parentTemplates\":[2],\"allowPageNum\":1,\"redirectLogin\":23,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1449860797}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('3', 'user', '3', '8', '0', '{\"useRoles\":1,\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"User\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('4', 'role', '4', '8', '0', '{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Role\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('5', 'permission', '5', '8', '0', '{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"guestSearchable\":1,\"pageClass\":\"Permission\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('1', 'home', '1', '0', '0', '{\"useRoles\":1,\"noParents\":1,\"slashUrls\":1,\"modified\":1459817107,\"roles\":[37]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('29', 'basic-page', '83', '0', '0', '{\"slashUrls\":1,\"modified\":1449860797}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('26', 'search', '80', '0', '0', '{\"noChildren\":1,\"noParents\":1,\"allowPageNum\":1,\"slashUrls\":1,\"modified\":1449860797}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('34', 'sitemap', '88', '0', '0', '{\"noChildren\":1,\"noParents\":1,\"redirectLogin\":23,\"slashUrls\":1,\"modified\":1449860797}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('43', 'language', '97', '8', '0', '{\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Language\",\"pageLabelField\":\"name\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noChangeTemplate\":1,\"noUnpublish\":1,\"nameContentTab\":1,\"modified\":1456334657}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('44', 'receta', '98', '0', '0', '{\"slashUrls\":1,\"modified\":1459435877,\"jsonFields\":[\"preparacion\",\"personas\",\"category\",\"dificultad\",\"images\",\"title\",\"ingredientes\",\"time\",\"tag1\",\"tag2\",\"tag3\",\"url\"]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('45', 'about', '99', '0', '0', '{\"slashUrls\":1,\"modified\":1459447002}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('48', 'sugerencias', '102', '0', '0', '{\"slashUrls\":1,\"modified\":1459392085}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('47', 'recetas', '101', '0', '0', '{\"slashUrls\":1,\"modified\":1459392149,\"jsonFields\":[\"crop\",\"title\"]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('50', 'pwangular', '104', '0', '0', '{\"urlSegments\":1,\"slashUrls\":1,\"modified\":1459385773,\"noPrependTemplateFile\":1,\"noAppendTemplateFile\":1}');

UPDATE pages SET created_users_id=41, modified_users_id=41, created=NOW(), modified=NOW();

# --- /WireDatabaseBackup {"numTables":32,"numCreateTables":39,"numInserts":1013,"numSeconds":0}