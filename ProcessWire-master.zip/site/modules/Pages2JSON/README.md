# Pages2JSON
Module for ProcessWire that adds capability to output pages as JSON

# Changelog
Homer Simpson (0.0.2)
* Allows user define global data output in module options + individual data based on template.
* Added forum user Manol's feature request regarding PageImage and PageFile fields.

Bart Simpson (0.0.1)
* Initial release
